<?php

$conn = new mysqli("localhost","root","","cuet_website");
if($conn->connect_error){
  die("connection failed:".$conn->connect_error);

}

?>