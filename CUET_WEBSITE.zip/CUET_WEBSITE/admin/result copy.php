<?php
session_start();
include("connect.php");

// Handle form submission for adding results
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_result'])) {
    $email = $_POST['email'];
    $department = $_POST['department'];
    $course_code = $_POST['course_code'];
    $course_name = $_POST['course_name'];
    $course_credit = $_POST['course_credit'];
    $batch = $_POST['batch'];
    $grade = $_POST['grade'];
    $semester = $_POST['semester'];
    
    // Validate inputs
    if (!empty($email) && !empty($department) && !empty($course_code) && 
        !empty($course_name) && !empty($course_credit) && !empty($batch) && 
        !empty($grade) && !empty($semester)) {
        
        $insert_query = mysqli_query($conn, "INSERT INTO results (email, department, course_code, course_name, course_credit, batch, grade, semester) 
                                            VALUES ('$email', '$department', '$course_code', '$course_name', '$course_credit', '$batch', '$grade', '$semester')");
        if ($insert_query) {
            $success_msg = "Result added successfully!";
        } else {
            $error_msg = "Error adding result: " . mysqli_error($conn);
        }
    } else {
        $error_msg = "All fields are required!";
    }
}

// Handle result deletion
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $delete_query = mysqli_query($conn, "DELETE FROM results WHERE id = $delete_id");
    if ($delete_query) {
        $success_msg = "Result deleted successfully!";
    } else {
        $error_msg = "Error deleting result: " . mysqli_error($conn);
    }
}

// Get current semester results if selected
$current_semester = isset($_GET['semester']) ? $_GET['semester'] : '';
$sort_by = isset($_GET['sort']) ? $_GET['sort'] : 'email'; // Default sort by email
$results = array();

if (!empty($current_semester)) {
    $order_by = '';
    switch ($sort_by) {
        case 'department':
            $order_by = 'department, batch, email';
            break;
        case 'batch':
            $order_by = 'batch, department, email';
            break;
        case 'email':
        default:
            $order_by = 'email, department, batch';
            break;
    }
    
    $results_query = mysqli_query($conn, "SELECT * FROM results WHERE semester = '$current_semester' ORDER BY $order_by");
    while ($row = mysqli_fetch_assoc($results_query)) {
        $results[] = $row;
    }
}

// Include header
include("header.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Results</title>
    <link href="../style.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .content-wrapper {
            display: flex;
            flex: 1;
        }
        .sidebar {
            width: 250px;
            background-color: #333;
            color: white;
            padding: 20px;
            box-sizing: border-box;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
        }
        .sidebar a:hover {
            background-color: #555;
        }
        .main-content {
            flex: 1;
            padding: 20px;
        }
        .dropdown-content {
            display: none;
            padding-left: 15px;
        }
        .dropdown.active .dropdown-content {
            display: block;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            cursor: pointer;
        }
        th.sort-asc:after {
            content: " ↑";
        }
        th.sort-desc:after {
            content: " ↓";
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input, select {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
        }
        .alert-success {
            color: #3c763d;
            background-color: #dff0d8;
            border-color: #d6e9c6;
        }
        .alert-danger {
            color: #a94442;
            background-color: #f2dede;
            border-color: #ebccd1;
        }
        .sort-options {
            margin: 15px 0;
            padding: 10px;
            background-color: #f5f5f5;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <?php include("header.php"); ?>
    
    <div class="content-wrapper">
        <div class="sidebar">
            <h2>Admin Panel</h2>
            <a href="admin.php">Dashboard</a>
            <div class="dropdown" id="resultsDropdown">
                <a href="#" onclick="toggleDropdown('resultsDropdown')">Publish Results</a>
                <div class="dropdown-content">
                    <a href="?semester=level1_term1">Level 1 Term 1</a>
                    <a href="?semester=level1_term2">Level 1 Term 2</a>
                    <a href="?semester=level2_term1">Level 2 Term 1</a>
                    <a href="?semester=level2_term2">Level 2 Term 2</a>
                    <a href="?semester=level3_term1">Level 3 Term 1</a>
                    <a href="?semester=level3_term2">Level 3 Term 2</a>
                    <a href="?semester=level4_term1">Level 4 Term 1</a>
                    <a href="?semester=level4_term2">Level 4 Term 2</a>
                </div>
            </div>
            <a href="logout.php">Logout</a>
        </div>

        <div class="main-content">
            <h1>Hello 
                <?php  
                if (isset($_SESSION['email'])) {
                    $email = $_SESSION['email'];
                    $query = mysqli_query($conn, "SELECT firstName, lastName FROM users WHERE email = '$email'");
                    if ($row = mysqli_fetch_assoc($query)) {
                        echo htmlspecialchars($row['firstName'] . ' ' . $row['lastName']);
                    }
                } else {
                    echo "Guest";
                }
                ?>
                :)
            </h1>

            <?php if (!empty($current_semester)): ?>
                <h2>Publish Results - <?php echo ucfirst(str_replace('_', ' ', $current_semester)); ?></h2>
                
                <?php if (isset($success_msg)): ?>
                    <div class="alert alert-success"><?php echo $success_msg; ?></div>
                <?php endif; ?>
                
                <?php if (isset($error_msg)): ?>
                    <div class="alert alert-danger"><?php echo $error_msg; ?></div>
                <?php endif; ?>
                
                <form method="POST" action="">
                    <input type="hidden" name="semester" value="<?php echo $current_semester; ?>">
                    
                    <div class="form-group">
                        <label for="email">Student Email</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="department">Department</label>
                        <input type="text" id="department" name="department" required>
                    </div>

                    <div class="form-group">
                        <label for="batch">Batch</label>
                        <input type="number" id="batch" name="batch" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="course_code">Course Code</label>
                        <input type="text" id="course_code" name="course_code" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="course_name">Course Name</label>
                        <input type="text" id="course_name" name="course_name" required>
                    </div>


                    <div class="form-group">
                         <label for="course_credit">Course Credit</label>
                        <input type="number" id="course_credit" name="course_credit" min="0.5" max="10" step="0.5" required>
                    </div>
                    
                    
                    
                    <div class="form-group">
                        <label for="grade">Grade</label>
                        <select id="grade" name="grade" required>
                            <option value="">Select Grade</option>
                            <option value="A+">A+</option>
                            <option value="A">A</option>
                            <option value="A-">A-</option>
                            <option value="B+">B+</option>
                            <option value="B">B</option>
                            <option value="B-">B-</option>
                            <option value="C+">C+</option>
                            <option value="C">C</option>
                            <option value="D">D</option>
                            <option value="F">F</option>
                        </select>
                    </div>
                    
                    <button type="submit" name="add_result">Add Result</button>
                </form>
                
                <h3>Current Results</h3>
                
                <div class="sort-options">
                    <strong>Sort by:</strong>
                    <a href="?semester=<?php echo $current_semester; ?>&sort=email" class="<?php echo $sort_by == 'email' ? 'active' : ''; ?>">Email</a> |
                    <a href="?semester=<?php echo $current_semester; ?>&sort=department" class="<?php echo $sort_by == 'department' ? 'active' : ''; ?>">Department</a> |
                    <a href="?semester=<?php echo $current_semester; ?>&sort=batch" class="<?php echo $sort_by == 'batch' ? 'active' : ''; ?>">Batch</a>
                </div>
                
                <?php if (count($results) > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th class="<?php echo $sort_by == 'email' ? 'sort-asc' : ''; ?>">Student Email</th>
                                <th class="<?php echo $sort_by == 'department' ? 'sort-asc' : ''; ?>">Department</th>
                                <th>Batch</th>
                                <th>Course Name</th>
                                <th class="<?php echo $sort_by == 'batch' ? 'sort-asc' : ''; ?>">Course Code</th>
                                <th>Grade</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($results as $result): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($result['email']); ?></td>
                                    <td><?php echo htmlspecialchars($result['department']); ?></td>
                                    <td><?php echo htmlspecialchars($result['batch']); ?></td>
                                    <td><?php echo htmlspecialchars($result['course_code']); ?></td>
                                    <td><?php echo htmlspecialchars($result['course_name']); ?></td>
                                    <td><?php echo htmlspecialchars($result['course_credit']); ?></td>
                                    
                                    <td><?php echo htmlspecialchars($result['grade']); ?></td>
                                    <td>
                                        <a href="?semester=<?php echo $current_semester; ?>&delete_id=<?php echo $result['id']; ?>" 
                                           onclick="return confirm('Are you sure you want to delete this result?')">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No results found for this semester.</p>
                <?php endif; ?>
            <?php else: ?>
                <p>Select a semester from the sidebar to publish results.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <?php include("footer.php"); ?>

    <script>
        function toggleDropdown(id) {
            document.getElementById(id).classList.toggle('active');
            return false;
        }
        
        // Activate dropdown if a semester is selected
        <?php if (!empty($current_semester)): ?>
            document.getElementById('resultsDropdown').classList.add('active');
        <?php endif; ?>
    </script>
</body>
</html>