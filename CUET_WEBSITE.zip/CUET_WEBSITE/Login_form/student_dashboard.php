<?php
session_start();
include 'connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Panel</title>
    <link rel="stylesheet" href="student_dashboard.css">
    <link rel="icon" href="logo.png" type="image/png">
    <link rel="stylesheet" href="../style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        .styled-table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
        }

        .styled-table th, .styled-table td {
            padding: 12px 15px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .styled-table th {
            background-color: #4275f5;
            font-weight: bold;
            color: white;
        }

        .styled-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .term {
            margin-bottom: 30px;
            border: 1px solid #eee;
            padding: 15px;
            border-radius: 5px;
        }

        .term h3 {
            margin-top: 0;
            color: #333;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            height: calc(100vh - 80px); /* Subtract header height */
            background: #2c3e50;
            position: fixed;
            top: 80px; /* Below header */
            left: 0;
            z-index: 900; /* Lower than header */
            padding-top: 20px;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
            overflow-y: auto;
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-menu li {
            padding: 15px;
            border-bottom: 1px solid #34495e;
            transition: all 0.3s;
        }

        .sidebar-menu li:hover {
            background: #34495e;
        }

        .sidebar-menu li a {
            color: #ecf0f1;
            text-decoration: none;
            display: block;
            font-size: 16px;
        }

        .sidebar-menu li a i {
            margin-right: 10px;
        }

        .sidebar-toggle {
            position: fixed;
            left: 20px;
            top: 20px;
            z-index: 1100;
            font-size: 24px;
            color: white;
            cursor: pointer;
            background: #2c3e50;
            padding: 10px;
            border-radius: 50%;
            display: none;
        }
       
        .main-content {
            margin-left: 280px;
            transition: margin-left 0.3s ease;
            padding: 20px;
            margin-top: 80px; /* Account for header height */
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                top: 80px; /* Below header */
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .sidebar-toggle {
                display: block;
            }
            .main-content {
                margin-left: 0;
            }
        }

        /* Header styles */
        header {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000; /* Higher than sidebar */
            left: 0;
            height: 80px;
            background: #2c3e50;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        footer{
          z-index: 1000;
          position: relative;
        }

        @media (min-width: 769px) {
            header {
                left: 0;
                width: 100%;
                padding-left: 270px; /* Account for sidebar */
            }
        }

        /* Adjust h1 margin */
        h1 {
            margin-top: 85px !important;
        }
    </style>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- Sidebar Toggle Button (Mobile only) -->
    <div class="sidebar-toggle" onclick="toggleSidebar()">
        ☰
    </div>

    <!-- Header -->
     <header>
  <div class="logo">
    <img src="logo.png" alt="CUET Logo">
    <h2>CUET</h2>
  </div>
  
  <div class="menu-icon" onclick="toggleMenu()">☰</div>
  
  <nav id="nav-links">
    <a href="../index.php">Home</a>
    <a href="../about.html">About CUET</a>
    <a href="../academic.html">Academic</a>
    <a href="../alumni.html">Alumni</a>
    <a href="../notice.php">Notice</a>
    
    
    <div class="dropdown">
      <a href="#" class="dropbtn">Login</a>
      <div class="dropdown-content">
         <a href="../Login_form/index.php">Student</a>
        <a href="../admin_login/index.php">Admin</a>
      
      </div>
    </div>
    <a href="logout.php">Logout</a>
  </nav>
</header>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar" >
        <h2 style="color: white; margin-left: 20px;">Student Panel</h2>
        <ul class="sidebar-menu">
            <li>
                <a href="student_dashboard.php">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </li>
            <li>
                <a href="update_profile.php">
                    <i class="fas fa-user-edit"></i> Update Profile
                </a>
            </li>
            <li>
                <a href="course_registration.php">
                    <i class="fas fa-book"></i> Course Registration
                </a>
            </li>
            <li>
                <a href="#student-result">
                    <i class="fas fa-chart-bar"></i> Results
                </a>
            </li>
            
            <!-- <li>
                <a href="class_routine.php">
                    <i class="fas fa-calendar-alt"></i> Class Routine
                </a>
            </li> -->
            
            <li>
                <a href="logout.php">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </li>
        </ul>
    </div>

    <h1 style="text-align: center;margin-top: 100px;">
        Welcome 
        <?php  
        if (isset($_SESSION['email'])) {
            $email = $_SESSION['email'];
            $query = mysqli_query($conn, "SELECT firstName, lastName FROM users WHERE email = '$email'");
            if ($row = mysqli_fetch_assoc($query)) {
                echo htmlspecialchars($row['firstName'] . ' ' . $row['lastName']);
            }
        } else {
            echo "Guest";
        }
        ?>
    </h1>

    <main class="student-container main-content" id="main-content">
        <!-- Student Info Section -->
<!-- Student Info Section -->
<!-- Student Info Section -->
<section class="student-info">
    <h2>Student Information</h2>
    <table class="styled-table" style="width: 100%;">
        <tbody>
            <tr>
                <td style="width: 70%; vertical-align: top;">
                    <table style="width: 100%; border: none;">
                        <tr>
                            <td style="border: none; padding: 8px 0;"><strong>Name:</strong></td>
                            <td style="border: none; padding: 8px 0;">
                                <?php
                                if(isset($_SESSION['email'])){
                                    $email= $_SESSION['email'];
                                    $query = mysqli_query($conn, "SELECT name FROM students_info WHERE email = '$email'");
                                    if($row = mysqli_fetch_assoc($query)){
                                        echo htmlspecialchars($row['name']);
                                    }
                                    else{
                                        echo "Name not found";
                                    }
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td style="border: none; padding: 8px 0;"><strong>ID:</strong></td>
                            <td style="border: none; padding: 8px 0;">
                                <?php
                                if(isset($_SESSION['email'])){
                                    $email= $_SESSION['email'];
                                    $query = mysqli_query($conn, "SELECT id FROM students_info WHERE email = '$email'");
                                    if($row = mysqli_fetch_assoc($query)){
                                        echo htmlspecialchars($row['id']);
                                    }
                                    else{
                                        echo "Id not found";
                                    }
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td style="border: none; padding: 8px 0;"><strong>Email:</strong></td>
                            <td style="border: none; padding: 8px 0;">
                                <?php
                                if(isset($_SESSION['email'])){
                                    $email= $_SESSION['email'];
                                    $query = mysqli_query($conn, "SELECT email FROM students_info WHERE email = '$email'");
                                    if($row = mysqli_fetch_assoc($query)){
                                        echo htmlspecialchars($row['email']);
                                    }
                                    else{
                                        echo "Email not found";
                                    }
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td style="border: none; padding: 8px 0;"><strong>Contact No:</strong></td>
                            <td style="border: none; padding: 8px 0;">
                                <?php
                                if(isset($_SESSION['email'])){
                                    $email= $_SESSION['email'];
                                    $query = mysqli_query($conn, "SELECT contact FROM students_info WHERE email = '$email'");
                                    if($row = mysqli_fetch_assoc($query)){
                                        echo htmlspecialchars($row['contact']);
                                    }
                                    else{
                                        echo "Contact not found";
                                    }
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td style="border: none; padding: 8px 0;"><strong>Department:</strong></td>
                            <td style="border: none; padding: 8px 0;">
                                <?php
                                if(isset($_SESSION['email'])){
                                    $email= $_SESSION['email'];
                                    $query = mysqli_query($conn, "SELECT department FROM students_info WHERE email = '$email'");
                                    if($row = mysqli_fetch_assoc($query)){
                                        echo htmlspecialchars($row['department']);
                                    }
                                    else{
                                        echo "Department not found";
                                    }
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td style="border: none; padding: 8px 0;"><strong>Batch:</strong></td>
                            <td style="border: none; padding: 8px 0;">
                                <?php
                                if(isset($_SESSION['email'])){
                                    $email= $_SESSION['email'];
                                    $query = mysqli_query($conn, "SELECT batch FROM students_info WHERE email = '$email'");
                                    if($row = mysqli_fetch_assoc($query)){
                                        echo htmlspecialchars($row['batch']);
                                    }
                                    else{
                                        echo "Batch not found";
                                    }
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td style="border: none; padding: 8px 0;"><strong>Hall:</strong></td>
                            <td style="border: none; padding: 8px 0;">
                                <?php
                                if(isset($_SESSION['email'])){
                                    $email= $_SESSION['email'];
                                    $query = mysqli_query($conn, "SELECT hall FROM students_info WHERE email = '$email'");
                                    if($row = mysqli_fetch_assoc($query)){
                                        echo htmlspecialchars($row['hall']);
                                    }
                                    else{
                                        echo "Hall not found";
                                    }
                                }
                                ?>
                            </td>
                        </tr>
                    </table>
                </td>
                <td style="width: 30%; text-align: center; vertical-align: middle; border-left: 1px solid #ddd;">
                    <?php
                    if(isset($_SESSION['email'])){
                        $email= $_SESSION['email'];
                        $query = mysqli_query($conn, "SELECT * FROM photos WHERE email = '$email'");
                        if($row = mysqli_fetch_assoc($query)){
                            echo "<img src='../admin/uploads/" . $row['filename'] . "' width='150' style='border: 1px solid #ddd; border-radius: 4px; padding: 5px;'>";
                        }
                        else{
                            echo "<p>Image not found</p>";
                        }
                    }
                    ?>
                </td>
            </tr>
        </tbody>
    </table>
</section>

    </main>


        <main class="student-container main-content" id="main-content">
        <!-- Student Result Section -->
        <section class="student-result"  id="student-result" style="margin-top: 20px;">
            <h2>Academic Results</h2>
            <?php
            if (isset($_SESSION['email'])) {
                $email = $_SESSION['email'];
                $semesters = [
                    'level1_term1' => 'Level 1 Term 1',
                    'level1_term2' => 'Level 1 Term 2',
                    'level2_term1' => 'Level 2 Term 1',
                    'level2_term2' => 'Level 2 Term 2',
                    'level3_term1' => 'Level 3 Term 1',
                    'level3_term2' => 'Level 3 Term 2',
                    'level4_term1' => 'Level 4 Term 1',
                    'level4_term2' => 'Level 4 Term 2'
                ];
                
                $grade_points = [
                    'A+' => 4.00,
                    'A' => 3.75,
                    'A-' => 3.50,
                    'B+' => 3.25,
                    'B' => 3.00,
                    'B-' => 2.75,
                    'C+' => 2.50,
                    'C' => 2.25,
                    'D' => 2.00,
                    'F' => 0.00
                ];
                
                foreach ($semesters as $semester_code => $semester_name) {
                    $query = mysqli_query($conn, "SELECT * FROM results WHERE email = '$email' AND semester = '$semester_code' ORDER BY course_code");
                    
                    if (mysqli_num_rows($query) > 0) {
                        $total_credits = 0;
                        $total_points = 0;
                        $courses = [];
                        
                        while ($row = mysqli_fetch_assoc($query)) {
                            $grade = $row['grade'];
                            $credit = $row['course_credit'];
                            
                            $courses[] = $row;
                            $total_credits += $credit;
                            $total_points += $credit * $grade_points[$grade];
                        }
                        
                        $cgpa = ($total_credits > 0) ? round($total_points / $total_credits, 2) : 0.00;
                        
                        echo '<div class="term">';
                        echo '<h3>' . $semester_name . ' (CGPA: ' . $cgpa . ')</h3>';
                        echo '<table class="styled-table">';
                        echo '<thead>';
                        echo '<tr>';
                        echo '<th>Course Code</th>';
                        echo '<th>Course Name</th>';
                        echo '<th>Credit</th>';
                        echo '<th>Grade</th>';
                        echo '</tr>';
                        echo '</thead>';
                        echo '<tbody>';
                        
                        foreach ($courses as $course) {
                            echo '<tr>';
                            echo '<td>' . htmlspecialchars($course['course_code']) . '</td>';
                            echo '<td>' . htmlspecialchars($course['course_name']) . '</td>';
                            echo '<td>' . htmlspecialchars($course['course_credit']) . '</td>';
                            echo '<td>' . htmlspecialchars($course['grade']) . '</td>';
                            echo '</tr>';
                        }
                        
                        echo '</tbody>';
                        echo '</table>';
                        echo '</div>';
                    }
                }
            }
            ?>
        </section>
    </main>

    <!-- Footer -->
    <footer>
    <div class="footer-section">
      <h3>Contact Us</h3>
      <p>Pahartoli, Raozan-4349 <br>Chittagong,Bangladesh</p>
      <p>Email: registrar@cuet.ac.bd</p>
      <p>Phone: +88xxxxxxxxx</p>
    </div>

    <div class="footer-section">
      <h3>Useful Links</h3>
      <a href="../index.php">Home</a>
  <a href="../about.php">About CUET</a>
  <a href="../academic.php">Academic</a>
  <a href="../alumni.php">Alumni</a>
  <a href="../notice.php">Notice</a>

      <div><br>
        @Copyright Chittagong University of Engineering And Technology
      </div>
    </div>
  </footer>

    <script>
        // Toggle sidebar function (Mobile only)
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('active');
        }

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(event) {
            const sidebar = document.getElementById('sidebar');
            const sidebarToggle = document.querySelector('.sidebar-toggle');
            const isClickInsideSidebar = sidebar.contains(event.target);
            const isClickOnToggle = sidebarToggle.contains(event.target);
            
            if (window.innerWidth <= 768 && !isClickInsideSidebar && !isClickOnToggle && sidebar.classList.contains('active')) {
                sidebar.classList.remove('active');
            }
        });

        // Existing toggle menu function
        function toggleMenu() {
            var navLinks = document.getElementById("nav-links");
            navLinks.classList.toggle("active");
        }

        // Ensure sidebar is visible on desktop when resizing
        window.addEventListener('resize', function() {
            const sidebar = document.getElementById('sidebar');
            if (window.innerWidth > 768) {
                sidebar.classList.remove('active');
            }
        });
    </script>
</body>
</html>