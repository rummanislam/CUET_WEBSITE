<?php
session_start();
include 'connect.php';

// Check if admin is logged in
// if (!isset($_SESSION['admin_logged_in'])) {
//     header("Location: ../admin_login/index.php");
//     exit();
// }

// Handle approval
if (isset($_GET['approve'])) {
    $id = $_GET['approve'];
    $conn->query("UPDATE course_registrations SET status='approved' WHERE id=$id");
    header("Location: admin_registration.php");
    exit();
}

// Get pending registrations
$pending_registrations = $conn->query("SELECT * FROM course_registrations WHERE status='pending'");

// Get approved registrations
$approved_registrations = $conn->query("SELECT * FROM course_registrations WHERE status='approved' ORDER BY registration_date DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Registration Approval</title>
    <link rel="stylesheet" href="admin.css">
    <link href="../style.css" rel="stylesheet">
    <style>

.sidebar {
    width: 250px;
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    background: #2c3e50;
    color: white;
    transition: all 0.3s;
    z-index: 999;
    padding-top: 20px;
    overflow-y: auto;
    margin-top: 79px;
}

.sidebar-toggle {
    display: none;
    position: fixed;
    left: 10px;
    top: 10px;
    z-index: 1001;
    cursor: pointer;
    color: white;
    font-size: 24px;
}

.sidebar h2 {
    color: white;
    text-align: center;
    margin-bottom: 20px;
    padding: 0 10px;
}

.sidebar ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.sidebar ul li {
    padding: 15px 20px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.sidebar ul li a {
    color: white;
    text-decoration: none;
    display: block;
}

.sidebar ul li a:hover {
    background: #34495e;
    padding-left: 25px;
}

.main-content {
    margin-left: 250px;
    transition: all 0.3s;
}

/* Mobile view */
@media (max-width: 768px) {
    .sidebar {
        left: -250px;
    }
    
    .sidebar.show {
        left: 0;
    }
    
    .sidebar-toggle {
        display: block;
    }
    
    .main-content {
        margin-left: 0;
    }
    
    .sidebar.show + .main-content {
        margin-left: 250px;
    }
}
        .registration-container {
            margin: 20px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        
        th {
            background-color: #f2f2f2;
        }
        
        .approve-btn {
            padding: 5px 10px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        
        h2 {
            margin-top: 30px;
            color: #333;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="sidebar" id="sidebar">
    <div class="sidebar-toggle">
        <!-- <span class="toggle-btn" onclick="toggleSidebar()">&#9776;</span> -->
    </div>
    <h2>Admin Panel</h2>
    <ul>
        <li><a href="admin.php">Dashboard</a></li>
        <li><a href="admin.php#studentSection">Update Student info</a></li>
        <li><a href="student_list.php" target="_blank">Student List</a></li>
        <li><a href="#">Courses</a></li>
        <li><a href="#">Departments</a></li>
        <li><a href="admin.php#noticeSection">Notices</a></li>
        <li><a href="result.php">Publish Result</a></li>
        <li><a href="admin_registration.php">Course Registration</a></li>
        <li><a href="../admin_login/logout.php">Logout</a></li>
    </ul>
</div>
    
    <div class="main-content">
        <div class="header">
            <span class="toggle-btn" onclick="toggleSidebar()">&#9776;</span>
            <h1>Course Registration Approval</h1>
        </div>
        
        <div class="registration-container">
            <h2>Pending Approvals</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Batch</th>
                        <th>Department</th>
                        <th>Hall</th>
                        <th>Level & Term</th>
                        <th>Payment Method</th>
                        <th>Transaction ID</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $pending_registrations->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['student_id']) ?></td>
                        <td><?= htmlspecialchars($row['student_name']) ?></td>
                        <td><?= htmlspecialchars($row['batch']) ?></td>
                        <td><?= htmlspecialchars($row['department']) ?></td>
                        <td><?= htmlspecialchars($row['hall']) ?></td>
                        <td><?= htmlspecialchars($row['level_term']) ?></td>
                        <td><?= htmlspecialchars($row['payment_method']) ?></td>
                        <td><?= htmlspecialchars($row['transaction_id']) ?></td>
                        <td>
                            <a href="?approve=<?= $row['id'] ?>" class="approve-btn">Approve</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            
            <h2>Approved Registrations</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Batch</th>
                        <th>Department</th>
                        <th>Hall</th>
                        <th>Level & Term</th>
                        <th>Payment Method</th>
                        <th>Transaction ID</th>
                        <th>Approval Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $approved_registrations->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['student_id']) ?></td>
                        <td><?= htmlspecialchars($row['student_name']) ?></td>
                        <td><?= htmlspecialchars($row['batch']) ?></td>
                        <td><?= htmlspecialchars($row['department']) ?></td>
                        <td><?= htmlspecialchars($row['hall']) ?></td>
                        <td><?= htmlspecialchars($row['level_term']) ?></td>
                        <td><?= htmlspecialchars($row['payment_method']) ?></td>
                        <td><?= htmlspecialchars($row['transaction_id']) ?></td>
                        <td><?= htmlspecialchars($row['registration_date']) ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('show');
        }
    </script>
</body>
</html>