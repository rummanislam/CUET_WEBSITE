<?php
session_start();
include 'connect.php';




// notice section
if(isset($_POST['post']))
{
  $message = $_POST['message'];
  $conn->query("INSERT INTO notice (notice) VALUES('$message') ");

  header("Location: ". $_SERVER['PHP_SELF']);
}

if(isset($_GET['delete'])){
  $sl = $_GET['delete'];
  $conn ->query("DELETE FROM notice WHERE sl = $sl");
  header("Location:" .$_SERVER['PHP_SELF']);
  exit;
}




if(isset($_POST['imp_post'])){
  $imp_message = $_POST['imp_message'];
  $conn->query("INSERT INTO important_notice (notice) VALUES('$imp_message') ");

  header("Location: ". $_SERVER['PHP_SELF']);
}

if(isset($_GET['imp_delete'])){
  $sl = $_GET['imp_delete'];
  $conn ->query("DELETE FROM important_notice WHERE sl = $sl");
  header("Location:" .$_SERVER['PHP_SELF']);
  exit;
}




//student section 
if(isset($_POST['sadd'])){
  $sname= $_POST['sname'];
  $sid= $_POST['sid'];
  $semail= $_POST['semail'];
  $scontact= $_POST['scontact'];
  $sdepartment= $_POST['sdepartment'];
  $sbatch= $_POST['sbatch'];
  $shall= $_POST['shall'];

  //$conn->query("INSERT INTO students_info (name, id, email,contact,department, batch,hall) VALUES ('$sname','$sid','$semail','$scontact','$sdepartment','$sbatch','$shall')");
  
  $check = $conn->query("SELECT * FROM students_info WHERE email = '$semail'");
  if ($check->num_rows > 0) {
     // echo "Student with this ID already exists.";
  } else {
      $conn->query("INSERT INTO students_info (name, id, email, contact, department, batch, hall) 
                    VALUES ('$sname', '$sid', '$semail', '$scontact', '$sdepartment', '$sbatch', '$shall')");
     // echo "Student added successfully.";
  }
  header("Location:" .$_SERVER['PHP_SELF']);     

}





// Get total student count from database
$student_count = 0;
$result = $conn->query("SELECT COUNT(*) as total FROM students_info");
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $student_count = $row['total'];
}



// Get total teacher count from database
$teacher_count = 0;
$result = $conn->query("SELECT COUNT(*) as total FROM teachers_info");
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $teacher_count = $row['total'];
}






// VC Section
if(isset($_POST['update_vc'])) {
    $vc_name = $_POST['vc_name'];
    $vc_message = $_POST['vc_message'];
    $photo_filename = ''; // Initialize variable

    // Handle file upload
    if(isset($_FILES['vc_photo']) && $_FILES['vc_photo']['error'] == 0) {
        $targetDir = "uploads/vc/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true);
        }
        
        $fileExt = pathinfo($_FILES['vc_photo']['name'], PATHINFO_EXTENSION);
        $photo_filename = uniqid() . '.' . $fileExt;
        $targetFile = $targetDir . $photo_filename;
        
        if(move_uploaded_file($_FILES['vc_photo']['tmp_name'], $targetFile)) {
            // File uploaded successfully
        }
    }

    // Check if VC info already exists
    $check = $conn->query("SELECT * FROM vc_info LIMIT 1");
    if ($check->num_rows > 0) {
        // Update existing record
        if(!empty($photo_filename)) {
            $conn->query("UPDATE vc_info SET name='$vc_name', message='$vc_message', photo_filename='$photo_filename'");
        } else {
            $conn->query("UPDATE vc_info SET name='$vc_name', message='$vc_message'");
        }
    } else {
        // Insert new record
        $conn->query("INSERT INTO vc_info (name, message, photo_filename) VALUES ('$vc_name', '$vc_message', '$photo_filename')");
    }
    
    header("Location: ". $_SERVER['PHP_SELF']);
    exit;
}

// Get current VC info
$vc_info = [];
$result = $conn->query("SELECT * FROM vc_info LIMIT 1");
if ($result && $result->num_rows > 0) {
    $vc_info = $result->fetch_assoc();
}







// History Section Operations
// Modify the history section code as follows:
    if(isset($_POST['add_history'])) {
        $title = $conn->real_escape_string($_POST['history_title']);
        $description = $conn->real_escape_string($_POST['history_description']);
        $photo_filename = '';
    
        // Handle file upload
        if(isset($_FILES['history_photo']) && $_FILES['history_photo']['error'] == 0) {
            $targetDir = "uploads/history/";
            if (!is_dir($targetDir)) {
                if (!mkdir($targetDir, 0755, true)) {
                    die("Failed to create upload directory");
                }
            }
            
            // Validate file type
            $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
            $fileExt = strtolower(pathinfo($_FILES['history_photo']['name'], PATHINFO_EXTENSION));
            
            if (!in_array($fileExt, $allowedTypes)) {
                die("Only JPG, JPEG, PNG, GIF files are allowed");
            }
            
            $photo_filename = uniqid() . '.' . $fileExt;
            $targetFile = $targetDir . $photo_filename;
            
            if(!move_uploaded_file($_FILES['history_photo']['tmp_name'], $targetFile)) {
                die("Failed to upload file");
            }
        }
    
        $sql = "INSERT INTO university_history (title, description, photo_filename) 
               VALUES ('$title', '$description', '$photo_filename')";
        
        if (!$conn->query($sql)) {
            die("Error adding history entry: " . $conn->error);
        }
        
        header("Location: ". $_SERVER['PHP_SELF']);
        exit;
    }

















// STUDENT photo upload
 


// Upload folder
$targetDir = "uploads/";

if (!is_dir($targetDir)) {
    mkdir($targetDir, 0777, true);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['sadd']) && isset($_FILES["photo"])) {
    $fileName = basename($_FILES["photo"]["name"]);
    $targetFilePath = $targetDir . $fileName;
    $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

    // Allowed types
    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
    $semail= $_POST['semail'];


    if (in_array(strtolower($fileType), $allowedTypes)) {
        if (move_uploaded_file($_FILES["photo"]["tmp_name"], $targetFilePath)) {
            // Save to database
            $sql = "INSERT INTO photos (email,filename) VALUES ('$semail','$fileName')";
            if ($conn->query($sql)) {
                //echo "Photo uploaded and saved!";
            } else {
                //echo "DB Error: " . $conn->error;
            }
        } else {
            //echo "File upload failed!";
        }
    } else {
       // echo "Only JPG, JPEG, PNG, GIF allowed.";
    }
} else {
    //echo "No file uploaded.";
}

//$conn->close();








// Teacher section 
// Modify the teacher section code as follows:
    if(isset($_POST['tadd'])){
        $tname = $_POST['tname'];
        $temail = $_POST['temail'];
        $tdesignation = $_POST['tdesignation'];
        $tcontact = $_POST['tcontact'];
        $tportfolio = $_POST['tportfolio'];
        $tuniversity = $_POST['tuniversity'];
        $tdepartment = $_POST['tdepartment'];
        $tjoin_date = $_POST['tjoin_date'];
        $photo_filename = '';
    
        // Handle file upload
        if(isset($_FILES['tphoto']) && $_FILES['tphoto']['error'] == 0) {
            $targetDir = "uploads/teachers/";
            if (!is_dir($targetDir)) {
                if (!mkdir($targetDir, 0755, true)) {
                    die("Failed to create upload directory");
                }
            }
            
            // Validate file type
            $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
            $fileExt = strtolower(pathinfo($_FILES['tphoto']['name'], PATHINFO_EXTENSION));
            
            if (!in_array($fileExt, $allowedTypes)) {
                die("Only JPG, JPEG, PNG, GIF files are allowed");
            }
            
            $photo_filename = uniqid() . '.' . $fileExt;
            $targetFile = $targetDir . $photo_filename;
            
            if(!move_uploaded_file($_FILES['tphoto']['tmp_name'], $targetFile)) {
                die("Failed to upload file");
            }
        }
    
        // Check if teacher exists
        $check = $conn->query("SELECT * FROM teachers_info WHERE email = '$temail'");
        if ($check && $check->num_rows == 0) {
            $sql = "INSERT INTO teachers_info 
                   (name, email, designation, contact, portfolio_link, 
                    undergrad_university, department, join_date, photo_filename) 
                   VALUES 
                   ('$tname', '$temail', '$tdesignation', '$tcontact', '$tportfolio', 
                    '$tuniversity', '$tdepartment', '$tjoin_date', '$photo_filename')";
            
            if (!$conn->query($sql)) {
                die("Error adding teacher: " . $conn->error);
            }
        } else {
            die("Teacher with this email already exists");
        }
        
        header("Location:" .$_SERVER['PHP_SELF']);     
        exit;
    }


























?>






<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>University Admin Panel</title>
  <link rel="icon" href="logo.png" type="image/png">
  <link href="admin.css" rel="stylesheet">
  <link href="../style.css" rel="stylesheet">
 
</head>
<body>




<header>
  <div class="logo">
    <img src="logo.png" alt="CUET Logo">
    <h2>CUET</h2>
  </div>
  
  <div class="menu-icon" onclick="toggleMenu()">☰</div>
  
  <nav id="nav-links">
    <a href="../index.php">Home</a>
      <a href="../about.php">About CUET</a>
      <a href="../academic.php">Academic</a>
      <a href="../alumni.php">Alumni</a>
      <a href="../notice.php">Notice</a>
    
    
    <div class="dropdown">
      <a href="#" class="dropbtn">Login</a>
      <div class="dropdown-content">
         <a href="../Login_form/index.php" target="_blank">Student</a>
      <a href="#" >Admin</a>
      
      </div>
    </div>
    <a href="../admin_login/logout.php" target="_blank">Logout</a>
  </nav>
</header>



<!-- 
<header>
    <div class="logo">
      <img src="logo.png" alt="CUET Logo">
      <h2>CUET</h2>
    </div>

    <div class="menu-icon" onclick="toggleMenu()">☰</div>

    <nav id="nav-links">
      <a href="../index.php">Home</a>
      <a href="../about.php">About CUET</a>
      <a href="../academic.php">Academic</a>
      <a href="../alumni.php">Alumni</a>
      <a href="../notice.php">Notice</a>
      <a href="../Login_form/index.php" target="_blank">Student Login</a>
      <a href="#" >Admin</a>
      <a href="../admin_login/logout.php" target="_blank">Logout</a>
    </nav>
  </header> -->


  <div class="sidebar" id="sidebar">
    <div class="sidebar-toggle">
      <span class="toggle-btn" onclick="toggleSidebar()">&#9776;</span>
    </div>
    <h2>Admin Panel</h2>
    <ul>
      <li><a href="#">Dashboard</a></li>
      <li><a href="#studentSection">Update Student info</a></li>
      <li><a href="#teacherSection">Update Teacher info</a></li>
      <li><a href="student_list.php" target="_blank">Student List</a></li>
      <li><a href="teacher_list.php" target="_blank">Teachers List</a></li>
      <!-- <li><a href="#">Courses</a></li> -->
      <li><a href="department.php">Departments</a></li>
      <li><a href="#noticeSection">Notices</a></li>
      <li><a href="result.php">Publish Result</a></li>
      <li><a href="admin_registration.php">Course Resigtration</a></li>
      <!-- <li><a href="#">Settings</a></li> -->
      <li><a href="../admin_login/logout.php">Logout</a></li>
    </ul>
  </div>

  <div class="main-content">
    <div class="header">
      <span class="toggle-btn" onclick="toggleSidebar()">&#9776;</span>
      <h1>Welcome, Admin</h1>
    </div>

    <div class="dashboard">
    <div class="card">
        <h3>Total Students</h3>
        <p><?php echo number_format($student_count); ?></p>
    </div>
    <div class="card"> 
    <h3>Total Teachers</h3>
    <p><?php echo number_format($teacher_count); ?></p>
</div>
      <div class="card">
        <h3>Courses Offered</h3>
        <p>85</p>
      </div>
      <div class="card">
        <h3>Departments</h3>
        <p>12</p>
      </div>
    </div>










<!-- Notice pannel starts -->
    <div style="display: flex; justify-content: space-around;flex-wrap:wrap;">
    <div class="notice-container">
    <!-- Regular Notice Section -->
    <div class="notice-section">
        <h2>Post a New Notice</h2>
        <form method="POST" class="notice-form">
            <input type="text" name="message" class="notice-input" placeholder="Enter notice here..." required>
            <input type="submit" name="post" value="Post Notice" class="post_notice">
        </form>
        
        <div class="notice-list">
            <h3>Recent Notices</h3>
            
            <?php
            $notice = $conn->query("SELECT * FROM notice ORDER BY date DESC");
            while($row = $notice->fetch_assoc()):
            ?>
            <div class="notice-item">
                <span class="notice-date"><?= date('M d, Y', strtotime($row['date'])) ?></span>
                <span class="notice-content"><?= $row['notice'] ?></span>
                <a href="?delete=<?=$row['sl']?>" class="delete-notice">Delete</a>
            </div>
            <?php endwhile; ?>
        </div>
    </div>

    <!-- Important Notice Section -->
    <div class="notice-section important-notice-section">
        <h2>Important Notice</h2>
        <form method="POST" class="notice-form">
            <input type="text" name="imp_message" class="notice-input" placeholder="Enter important notice here..." required>
            <input type="submit" name="imp_post" value="Post Important Notice" class="post_notice">
        </form>
        
        <div class="notice-list">
            <h3>Important Notices</h3>
            
            <?php
            $notice = $conn->query("SELECT * FROM important_notice ORDER BY date DESC");
            while($row = $notice->fetch_assoc()):
            ?>
            <div class="notice-item important-notice-item">
                <span class="notice-date"><?= date('M d, Y', strtotime($row['date'])) ?></span>
                <span class="notice-content"><?= $row['notice'] ?></span>
                <a href="?imp_delete=<?=$row['sl']?>" class="delete-notice">Delete</a>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</div>




     
    </div>



    <!-- VC Section -->
<div class="vc-section" id="vcSection">
    <h2>Vice Chancellor Information</h2>
    
    <form action="" method="post" enctype="multipart/form-data" class="vc-form">
        <div class="vc-form-container">
            <div class="vc-form-group">
                <label for="vcName">VC Name</label>
                <input type="text" name="vc_name" class="vc-form-control" id="vcName" 
                       placeholder="Enter Vice Chancellor's name" 
                       value="<?= isset($vc_info['name']) ? htmlspecialchars($vc_info['name']) : '' ?>" required>
            </div>
            
            <div class="vc-form-group">
                <label for="vcMessage">VC Message</label>
                <textarea name="vc_message" class="vc-form-control" id="vcMessage" 
                          placeholder="Enter VC's message" rows="4" required><?= isset($vc_info['message']) ? htmlspecialchars($vc_info['message']) : '' ?></textarea>
            </div>
            
            <div class="vc-form-group">
                <label for="vcPhoto">VC Photo</label>
                <input type="file" name="vc_photo" class="vc-photo-upload" id="vcPhoto" accept="image/*">
                <?php if(isset($vc_info['photo_filename']) && !empty($vc_info['photo_filename'])): ?>
                    <div class="vc-photo-preview-container">
                        <p>Current Photo:</p>
                        <img src="uploads/vc/<?= htmlspecialchars($vc_info['photo_filename']) ?>" 
                             class="vc-photo-preview" alt="Current VC Photo">
                    </div>
                <?php endif; ?>
                <img id="vcPhotoPreview" class="vc-photo-preview" style="display: none;" alt="Photo preview">
            </div>
        </div>
        
        <button type="submit" name="update_vc" class="vc-submit-btn">Update VC Information</button>
    </form>
</div>








<!-- History Section -->
<!-- History Section -->
<div class="history-section" id="historySection">
    <h2>University History Management</h2>
    
    <form action="" method="post" enctype="multipart/form-data" class="history-form">
        <div class="form-group">
            <label for="history_title">Title:</label>
            <input type="text" name="history_title" id="history_title" class="form-control" required>
        </div>
        
        <div class="form-group">
            <label for="history_description">Description:</label>
            <textarea name="history_description" id="history_description" class="form-control" rows="5" required></textarea>
        </div>
        
        <div class="form-group">
            <label for="history_photo">Photo (Optional):</label>
            <input type="file" name="history_photo" id="history_photo" class="form-control" accept="image/*">
            <img id="historyPhotoPreview" src="#" alt="Preview" style="display: none; max-width: 200px; margin-top: 10px;">
        </div>
        
        <button type="submit" name="add_history" class="btn btn-primary">Add History Entry</button>
    </form>
    
    <div class="history-entries-list" style="margin-top: 30px;">
        <h3>Current History Entries</h3>
        
        <?php if(empty($history_entries)): ?>
            <p>No history entries yet.</p>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Photo</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($history_entries as $entry): ?>
                        <tr>
                            <td>
                                <?php if(!empty($entry['photo_filename'])): ?>
                                    <img src="uploads/history/<?= htmlspecialchars($entry['photo_filename']) ?>" alt="<?= htmlspecialchars($entry['title']) ?>" style="max-width: 100px;">
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($entry['title']) ?></td>
                            <td><?= htmlspecialchars(nl2br(substr($entry['description'], 0, 100))) . (strlen($entry['description']) > 100 ? '...' : '') ?></td>
                            <td><?= date('M d, Y', strtotime($entry['created_at'])) ?></td>
                            <td>
                                <a href="?delete_history=<?= $entry['id'] ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this history entry?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

















    <div class="student-section" id="studentSection">
    <h2>Student Information Management</h2>
    <h4>Student Data Entry</h4>
    
    <form action="" method="post" enctype="multipart/form-data" class="student-form">
        <div class="student-form-container">
            <!-- Left Column -->
            <div class="student-form-column">
                <div class="student-form-group">
                    <label for="studentName">Full Name</label>
                    <input type="text" name="sname" class="student-form-control" id="studentName" placeholder="Enter student's full name" required>
                </div>
                
                <div class="student-form-group">
                    <label for="studentId">Student ID</label>
                    <input type="text" name="sid" class="student-form-control" id="studentId" placeholder="Enter student ID" required>
                </div>
                
                <div class="student-form-group">
                    <label for="studentEmail">Email Address</label>
                    <input type="email" name="semail" class="student-form-control" id="studentEmail" placeholder="Enter student email" required>
                </div>
                
                <div class="student-form-group">
                    <label for="studentContact">Contact Number</label>
                    <input type="tel" name="scontact" class="student-form-control" id="studentContact" placeholder="Enter contact number" required>
                </div>
            </div>
            
            <!-- Right Column -->
            <div class="student-form-column">
                <div class="student-form-group">
                    <label for="studentDepartment">Department</label>
                    <input type="text" name="sdepartment" class="student-form-control" id="studentDepartment" placeholder="Enter department" required>
                </div>
                
                <div class="student-form-group">
                    <label for="studentBatch">Batch</label>
                    <input type="text" name="sbatch" class="student-form-control" id="studentBatch" placeholder="Enter batch year" required>
                </div>
                
                <div class="student-form-group">
                    <label for="studentHall">Hall of Residence</label>
                    <input type="text" name="shall" class="student-form-control" id="studentHall" placeholder="Enter hall name" required>
                </div>
                
                <div class="student-form-group">
                    <label for="studentPhoto">Student Photo</label>
                    <input type="file" name="photo" class="student-photo-upload" id="studentPhoto" accept="image/*" required>
                    <img id="photoPreview" class="student-photo-preview" alt="Photo preview">
                </div>
            </div>
        </div>
        
        <div class="student-action-buttons">
            <button type="submit" class="student-submit-btn" name="sadd">Add Student</button>
            <a href="student_list.php" class="student-view-btn">View Student List</a>
        </div>
    </form>
</div>



  


    <!-- 🧪 Result Section -->
    <!-- <div class="result-section" id="resultSection">
      <h2>Publish Result</h2>
      <input type="text" class="result-input" id="studentName" placeholder="Student Name" />
      <input type="text" class="result-input" id="courseName" placeholder="Course Name" />
      <input type="text" class="result-input" id="marks" placeholder="Marks Obtained" />
      <button class="result-button" onclick="publishResult()">Publish Result</button>
      <div class="result-list" id="resultList"></div>
    </div>    -->

    
    <div class="teacher-section" id="teacherSection">
    <h2>Teacher Information Management</h2>
    <h4>Teacher Data Entry</h4>
    
    <form action="" method="post" enctype="multipart/form-data" class="teacher-form">
        <div class="teacher-form-container">
            <!-- Left Column -->
            <div class="teacher-form-column">
                <div class="teacher-form-group">
                    <label for="teacherName">Full Name</label>
                    <input type="text" name="tname" class="teacher-form-control" id="teacherName" placeholder="Enter teacher's full name" required>
                </div>
                
                <div class="teacher-form-group">
                    <label for="teacherEmail">Email Address</label>
                    <input type="email" name="temail" class="teacher-form-control" id="teacherEmail" placeholder="Enter teacher email" required>
                </div>
                
                <div class="teacher-form-group">
                    <label for="teacherDesignation">Designation</label>
                    <select name="tdesignation" class="teacher-form-control" id="teacherDesignation" required>
                        <option value="">Select Designation</option>
                        <option value="Professor">Professor</option>
                        <option value="Associate Professor">Associate Professor</option>
                        <option value="Assistant Professor">Assistant Professor</option>
                        <option value="Lecturer">Lecturer</option>
                    </select>
                </div>
                
                <div class="teacher-form-group">
                    <label for="teacherContact">Contact Number</label>
                    <input type="tel" name="tcontact" class="teacher-form-control" id="teacherContact" placeholder="Enter contact number" required>
                </div>
            </div>
            
            <!-- Right Column -->
            <div class="teacher-form-column">
                <div class="teacher-form-group">
                    <label for="teacherDepartment">Department</label>
                    <select name="tdepartment" class="teacher-form-control" id="teacherDepartment" required>
                        <option value="">Select Department</option>
                        
            <option value="ETE" >ETE</option>
            <option value="EEE" >EEE</option>
            <option value="CSE" >CSE</option>
            <option value="BME" >BME</option>
            <option value="CE" >CE</option>
            <option value="WRE" >WRE</option>
            <option value="ME" >ME</option>
            <option value="PME" >PME</option>
            <option value="MIE" >MIE</option>
            <option value="MME" >MME</option>
                        <!-- Add other departments as needed -->
                    </select>
                </div>
                
                <div class="teacher-form-group">
                    <label for="teacherPortfolio">Portfolio Link</label>
                    <input type="url" name="tportfolio" class="teacher-form-control" id="teacherPortfolio" placeholder="Enter portfolio URL">
                </div>
                
                <div class="teacher-form-group">
                    <label for="teacherUniversity">Undergrad University</label>
                    <input type="text" name="tuniversity" class="teacher-form-control" id="teacherUniversity" placeholder="Enter undergraduate university">
                </div>
                
                <div class="teacher-form-group">
                    <label for="teacherJoinDate">Join Date</label>
                    <input type="date" name="tjoin_date" class="teacher-form-control" id="teacherJoinDate" required>
                </div>
            </div>
            
            <!-- Photo Column -->
            <div class="teacher-form-column">
                <div class="teacher-form-group">
                    <label for="teacherPhoto">Teacher Photo</label>
                    <input type="file" name="tphoto" class="teacher-photo-upload" id="teacherPhoto" accept="image/*">
                    <img id="teacherPhotoPreview" class="teacher-photo-preview" alt="Photo preview">
                </div>
            </div>
        </div>
        
        <div class="teacher-action-buttons">
            <button type="submit" class="teacher-submit-btn" name="tadd">Add Teacher</button>
            <a href="teacher_list.php" class="teacher-view-btn">View Teacher List</a>
        </div>
    </form>
</div>


    


  </div>



  </div>







  <script>
    function toggleSidebar() {
      const sidebar = document.getElementById('sidebar');
      sidebar.classList.toggle('show');
    }

    function postNotice() {
      const input = document.getElementById('noticeInput');
      const noticeText = input.value.trim();
      if (!noticeText) return;

      const item = document.createElement('div');
      item.className = 'notice-item';
      item.textContent = noticeText;
      document.getElementById('noticeList').prepend(item);
      input.value = '';
    }

    function publishResult() {
      const name = document.getElementById('studentName').value.trim();
      const course = document.getElementById('courseName').value.trim();
      const marks = document.getElementById('marks').value.trim();
      if (!name || !course || !marks) return;

      const item = document.createElement('div');
      item.className = 'result-item';
      item.textContent = `Student: ${name}, Course: ${course}, Marks: ${marks}`;
      document.getElementById('resultList').prepend(item);

      document.getElementById('studentName').value = '';
      document.getElementById('courseName').value = '';
      document.getElementById('marks').value = '';
    }
  </script>
    <script>
    function toggleMenu() {
      var navLinks = document.getElementById("nav-links");
      navLinks.classList.toggle("active");
    }








    document.getElementById('teacherPhoto').addEventListener('change', function(e) {
    const preview = document.getElementById('teacherPhotoPreview');
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
        }
        reader.readAsDataURL(file);
    } else {
        preview.style.display = 'none';
    }
});





document.getElementById('vcPhoto').addEventListener('change', function(e) {
    const preview = document.getElementById('vcPhotoPreview');
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
        }
        reader.readAsDataURL(file);
    } else {
        preview.style.display = 'none';
    }
});





// History photo preview
document.getElementById('history_photo').addEventListener('change', function(e) {
    const preview = document.getElementById('historyPhotoPreview');
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
        }
        reader.readAsDataURL(file);
    } else {
        preview.style.display = 'none';
    }
});





  </script>
</body>
</html>
