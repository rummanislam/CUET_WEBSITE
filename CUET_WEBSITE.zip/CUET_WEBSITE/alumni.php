<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni | CUET</title>
    <link rel="icon" href="logo.png" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="alumni.css">
    <link rel="stylesheet" href="style.css">
    <style>
        /* Alumni Feature Cards with Different Colors */
        .alumni-features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-top: 40px;
        }
        
        .feature-card {
            background: #fff;
            border-radius: 10px;
            padding: 30px;
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            border-top: 5px solid #3498db;
        }
        
        /* Color variations for feature cards */
        .feature-card:nth-child(3n+1) {
            border-top-color: #3498db;
            background-color: #e3f2fd;
        }
        .feature-card:nth-child(3n+2) {
            border-top-color: #2ecc71;
            background-color: #e8f5e9;
        }
        .feature-card:nth-child(3n+3) {
            border-top-color: #e74c3c;
            background-color: #ffebee;
        }
        
        /* Icon colors to match cards */
        .feature-card:nth-child(3n+1) i {
            color: #1976d2;
        }
        .feature-card:nth-child(3n+2) i {
            color: #388e3c;
        }
        .feature-card:nth-child(3n+3) i {
            color: #d32f2f;
        }
        
        .feature-card i {
            font-size: 40px;
            margin-bottom: 20px;
        }
        
        .feature-card h4 {
            font-size: 1.3rem;
            margin-bottom: 15px;
            color: #2c3e50;
        }
        
        .feature-card p {
            color: #555;
            line-height: 1.6;
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }
        
        /* Alumni stats styling */
        .alumni-stats {
            display: flex;
            gap: 20px;
            margin: 25px 0;
        }
        
        .stat-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 15px;
            border-radius: 8px;
            background-color: #f8f9fa;
        }
        
        .stat-item i {
            font-size: 24px;
            color: #3498db;
        }
        
        .stat-number {
            display: block;
            font-size: 1.5rem;
            font-weight: 600;
            color: #2c3e50;
        }
        
        .stat-label {
            display: block;
            font-size: 0.9rem;
            color: #7f8c8d;
        }
    </style>
</head>
<body>
     
<?php
   include 'header.php';
?>

  <section class="alumni-section">
    <div class="container">
        <div class="section-header">
            <h2>Alumni</h2>
        </div>
        
        <div class="alumni-content">
            <div class="alumni-image">
                <img src="alumni.jpg" alt="CUET Alumni Gathering">
            </div>
            
            <div class="alumni-text">
                <h3>CUET Alumni Association</h3>
                <p>The Chittagong University of Engineering and Technology (CUET) Alumni Association is a platform for former students to stay connected with their alma mater and fellow graduates. Our alumni are working in prestigious positions around the world, contributing to various sectors including engineering, academia, research, and industry.</p>
                
                <div class="alumni-stats">
                    <div class="stat-item">
                        <i class="fas fa-users"></i>
                        <div>
                            <span class="stat-number">10,000+</span>
                            <span class="stat-label">Alumni Members</span>
                        </div>
                    </div>
                    <div class="stat-item">
                        <i class="fas fa-globe"></i>
                        <div>
                            <span class="stat-number">30+</span>
                            <span class="stat-label">Countries Worldwide</span>
                        </div>
                    </div>
                </div>
                
                <div class="alumni-buttons">
                    <a href="register_alumni.php" class="alumni-btn register-btn">
                        <i class="fas fa-user-plus"></i> Register
                    </a>
                    <a href="alumni_directory.php" class="alumni-btn directory-btn">
                        <i class="fas fa-address-book"></i> Alumni Directory
                    </a>
                </div>
            </div>
        </div>
        
        <div class="alumni-features">
            <div class="feature-card">
                <i class="fas fa-calendar-alt"></i>
                <h4>Alumni Events</h4>
                <p>Annual reunions, networking events, and professional development workshops</p>
            </div>
            <div class="feature-card">
                <i class="fas fa-hand-holding-usd"></i>
                <h4>Support CUET</h4>
                <p>Opportunities to give back through scholarships and infrastructure development</p>
            </div>
            <div class="feature-card">
                <i class="fas fa-briefcase"></i>
                <h4>Career Support</h4>
                <p>Job placement assistance and internship opportunities for current students</p>
            </div>
        </div>
    </div>
</section>
  
<?php
  include 'footer.php';
?>
  
  <script>
    function toggleMenu() {
      var navLinks = document.getElementById("nav-links");
      navLinks.classList.toggle("active");
    }
  </script>
</body>
</html>