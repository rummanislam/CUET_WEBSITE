<?php
$host = "localhost";
$user = "root";
$password = ""; // your MySQL password
$dbname = "cuet_website";

// Connect to database
$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Upload folder
$targetDir = "uploads/";

if (!is_dir($targetDir)) {
    mkdir($targetDir, 0777, true);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["photo"])) {
    $fileName = basename($_FILES["photo"]["name"]);
    $targetFilePath = $targetDir . $fileName;
    $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

    // Allowed types
    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];

    if (in_array(strtolower($fileType), $allowedTypes)) {
        if (move_uploaded_file($_FILES["photo"]["tmp_name"], $targetFilePath)) {
            // Save to database
            $sql = "INSERT INTO photos (filename) VALUES ('$fileName')";
            if ($conn->query($sql)) {
                echo "Photo uploaded and saved!";
            } else {
                echo "DB Error: " . $conn->error;
            }
        } else {
            echo "File upload failed!";
        }
    } else {
        echo "Only JPG, JPEG, PNG, GIF allowed.";
    }
} else {
    echo "No file uploaded.";
}

$conn->close();
?>
