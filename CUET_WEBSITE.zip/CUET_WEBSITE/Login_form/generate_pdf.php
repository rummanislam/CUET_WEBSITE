<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['email'])) {
    header("Location: ../Login_form/index.php");
    exit();
}

// Get student info and latest registration
$email = $_SESSION['email'];
$student_info = $conn->query("SELECT * FROM students_info WHERE email='$email'")->fetch_assoc();
$registration_info = $conn->query("SELECT * FROM course_registrations WHERE student_email='$email' ORDER BY registration_date DESC LIMIT 1")->fetch_assoc();
$photo_info = $conn->query("SELECT * FROM photos WHERE email='$email'")->fetch_assoc();

// Check if registration is approved
if (!$registration_info || $registration_info['status'] != 'approved') {
    header("Location: course_registration.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form - CUET</title>
    <style>
        @page {
            size: A4;
            margin: 0;
        }
        
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 20px;
            color: #333;
            line-height: 1.4;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        
        .page-container {
            width: 210mm;
            min-height: 297mm;
            background: white;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            border: 1px solid #ddd;
            position: relative;
            padding: 0;
        }
        
        .a4-container {
            width: 100%;
            height: 100%;
            padding: 12mm 15mm;
            box-sizing: border-box;
            position: relative;
        }
        
        .header {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
            padding-bottom: 8px;
            border-bottom: 2px solid #003366;
        }
        
        .logo {
            width: 60px;
            height: 60px;
        }
        
        .university-name {
            text-align: center;
            flex-grow: 1;
        }
        
        .university-name h1 {
            margin: 0;
            font-size: 18px;
            color: #003366;
            font-weight: 700;
        }
        
        .university-name h2 {
            margin: 3px 0 0;
            font-size: 15px;
            color: #003366;
            font-weight: 500;
        }
        
        .form-title {
            text-align: center;
            margin: 10px 0 15px;
            font-size: 16px;
            text-decoration: underline;
            font-weight: 600;
        }
        
        .content-wrapper {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
        }
        
        .student-details {
            width: 65%;
        }
        
        .student-photo {
            width: 32%;
            text-align: right;
            padding-top: 5px;
        }
        
        .photo-container {
            width: 110px;
            height: 140px;
            display: inline-block;
            border: 1px solid #e0e0e0;
            overflow: hidden;
        }
        
        .photo-container img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px 15px;
        }
        
        .info-item {
            margin-bottom: 30px;
        }
        
        .info-label {
            font-weight: 600;
            color: #555;
            display: block;
            margin-bottom: 1px;
            font-size: 13px;
        }
        
        .info-value {
            padding: 4px 0;
            border-bottom: 1px solid #e0e0e0;
            font-size: 13px;
            min-height: 18px;
        }
        
        .signature-area {
            position: absolute;
            bottom: 25mm;
            left: 15mm;
            right: 15mm;
            display: flex;
            justify-content: space-between;
            padding-top: 15px;
            border-top: 1px solid #ddd;
        }
        
        .signature-box {
            text-align: center;
            width: 30%;
        }
        
        .signature-line {
            width: 80%;
            height: 1px;
            background-color: #333;
            margin: 30px auto 8px;
        }
        
        .signature-label {
            font-size: 12px;
            color: #555;
        }
        
        .footer {
            position: absolute;
            bottom: 8mm;
            left: 15mm;
            right: 15mm;
            text-align: center;
            font-size: 11px;
            color: #777;
        }
        
        .print-btn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 8px 16px;
            background-color: #003366;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            z-index: 1000;
            font-weight: 500;
            font-size: 14px;
        }
        
        @media print {
            body {
                background: none;
                padding: 0;
            }
            
            .page-container {
                box-shadow: none;
                border: none;
                margin: 0;
            }
            
            .print-btn {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="page-container">
        <div class="a4-container">
            <div class="header">
                <img src="logo.png" alt="CUET Logo" class="logo">
                <div class="university-name">
                    <h1>CHITTAGONG UNIVERSITY OF ENGINEERING AND TECHNOLOGY</h1>
                    <h2>CHITTAGONG - 4349</h2>
                    <h2>Course Registration Form</h2>
                </div>
            </div>
            
            <div class="form-title">Student Information and Course Registration Details</div>
            
            <div class="content-wrapper">
                <div class="student-details">
                    <div class="info-grid">
                        <div class="info-item">
                            <span class="info-label">Student Name</span>
                            <div class="info-value"><?= htmlspecialchars($student_info['name']) ?></div>
                        </div>
                        
                        <div class="info-item">
                            <span class="info-label">Student ID</span>
                            <div class="info-value"><?= htmlspecialchars($student_info['id']) ?></div>
                        </div>
                        
                        <div class="info-item">
                            <span class="info-label">Email</span>
                            <div class="info-value"><?= htmlspecialchars($student_info['email']) ?></div>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Contact Number</span>
                            <div class="info-value"><?= htmlspecialchars($student_info['contact']) ?></div>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Department</span>
                            <div class="info-value"><?= htmlspecialchars($student_info['department']) ?></div>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Batch</span>
                            <div class="info-value"><?= htmlspecialchars($student_info['batch']) ?></div>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Hall</span>
                            <div class="info-value"><?= htmlspecialchars($student_info['hall']) ?></div>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Level & Term</span>
                            <div class="info-value"><?= htmlspecialchars($registration_info['level_term']) ?></div>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Course Registration Fee</span>
                            <div class="info-value"><?= htmlspecialchars($registration_info['course_fee']) ?> BDT</div>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Payment Method</span>
                            <div class="info-value"><?= htmlspecialchars($registration_info['payment_method']) ?></div>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Transaction ID</span>
                            <div class="info-value"><?= htmlspecialchars($registration_info['transaction_id']) ?></div>
                        </div>
                    </div>
                </div>
                
                <div class="student-photo">
                    <div class="photo-container">
                        <?php if ($photo_info && !empty($photo_info['filename'])): ?>
                            <img src="../admin/uploads/<?= htmlspecialchars($photo_info['filename']) ?>" alt="Student Photo">
                        <?php else: ?>
                            <div style="width:100%; height:100%; background:#f5f5f5; display:flex; align-items:center; justify-content:center;">
                                Photo Not Available
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <br><br><br><br><br><br><br><br> <br><br><br><br><br><br><br><br>
            <div class="signature-area">
                <div class="signature-box">
                    <div class="signature-line"></div>
                    <div class="signature-label">Student's Signature</div>
                </div>
                <div class="signature-box">
                    <div class="signature-line"></div>
                    <div class="signature-label">Department Head Signature</div>
                </div>
                <div class="signature-box">
                    <div class="signature-line"></div>
                    <div class="signature-label">Advisor Signagure</div>
                </div>
            </div>
            
            <div class="footer">
                <p>Generated on <?= date('F j, Y') ?> | Computerized Registration System - CUET</p>
            </div>
        </div>
    </div>
    
    <button class="print-btn" onclick="window.print()">Print Registration Form</button>
</body>
</html>