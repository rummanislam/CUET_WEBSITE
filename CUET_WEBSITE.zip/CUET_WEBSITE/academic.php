<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Academic Departments | CUET</title>
    <link rel="icon" href="logo.png" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        /* Department Cards - Matching department.php style */
        .department-grid {
    display: grid;
    grid-template-columns: 1fr; /* Single column */
    gap: 20px;
    margin-top: 30px;
    max-width: 800px; /* Optional: Limit width for better readability */
    margin-left: auto;
    margin-right: auto;
}



@media (min-width: 1px) { /* Applies to all screen sizes */
    .department-grid {
        grid-template-columns: 1fr !important;
    }
}
        
        .department-card {
            background-color: #fff;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.03);
            transition: all 0.3s ease;
            margin-bottom: 20px;
            border-left: 4px solid #3498db;
        }
        
        /* Color variations for department cards background */
        .department-card:nth-child(6n+1) {
            background-color: #e3f2fd; /* Light blue */
            border-left-color: #1976d2;
        }
        .department-card:nth-child(6n+2) {
            background-color: #e8f5e9; /* Light green */
            border-left-color: #388e3c;
        }
        .department-card:nth-child(6n+3) {
            background-color: #ffebee; /* Light red */
            border-left-color: #d32f2f;
        }
        .department-card:nth-child(6n+4) {
            background-color: #fff8e1; /* Light orange */
            border-left-color: #ffa000;
        }
        .department-card:nth-child(6n+5) {
            background-color: #f3e5f5; /* Light purple */
            border-left-color: #7b1fa2;
        }
        .department-card:nth-child(6n+6) {
            background-color: #e0f7fa; /* Light teal */
            border-left-color: #0097a7;
        }
        
        /* Color variations for department titles to match the theme */
        .department-card:nth-child(6n+1) .department-title {
            color: #1976d2;
        }
        .department-card:nth-child(6n+2) .department-title {
            color: #388e3c;
        }
        .department-card:nth-child(6n+3) .department-title {
            color: #d32f2f;
        }
        .department-card:nth-child(6n+4) .department-title {
            color: #ffa000;
        }
        .department-card:nth-child(6n+5) .department-title {
            color: #7b1fa2;
        }
        .department-card:nth-child(6n+6) .department-title {
            color: #0097a7;
        }
        
        /* Adjust toggle button color to match theme */
        .department-card:nth-child(6n+1) .toggle-description {
            color: #1976d2;
        }
        .department-card:nth-child(6n+2) .toggle-description {
            color: #388e3c;
        }
        .department-card:nth-child(6n+3) .toggle-description {
            color: #d32f2f;
        }
        .department-card:nth-child(6n+4) .toggle-description {
            color: #ffa000;
        }
        .department-card:nth-child(6n+5) .toggle-description {
            color: #7b1fa2;
        }
        .department-card:nth-child(6n+6) .toggle-description {
            color: #0097a7;
        }
        
        .department-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        
        .department-header {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .department-logo {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 15px;
            border: 2px solid rgba(0,0,0,0.1);
            background-color: rgba(255,255,255,0.8);
        }
        
        .department-title {
            font-size: 1.2rem;
            margin: 0;
            transition: color 0.3s ease;
        }
        
        .department-code {
            font-size: 0.9rem;
            color: #666;
            margin: 5px 0 0;
        }
        
        .department-details {
            margin-top: 15px;
        }
        
        .department-detail {
            display: flex;
            margin-bottom: 8px;
        }
        
        .detail-label {
            font-weight: 500;
            min-width: 120px;
        }
        
        /* Description toggle styles */
        .description-container {
            position: relative;
        }
        
        .description-text {
            line-height: 1.5;
            overflow: hidden;
            transition: max-height 0.3s ease;
        }
        
        .description-short {
            max-height: 60px; /* About 3 lines of text */
        }
        
        .description-full {
            max-height: 1000px; /* Enough to show full content */
        }
        
        .toggle-description {
            background: none;
            border: none;
            font-weight: 500;
            cursor: pointer;
            padding: 5px 0;
            display: inline-flex;
            align-items: center;
            margin-top: 5px;
        }
        
        .toggle-description i {
            margin-left: 5px;
            transition: transform 0.3s ease;
        }
        
        .toggle-description:hover {
            opacity: 0.8;
        }
        
        /* Section header styles */
        .section-header {
            text-align: center;
            margin-bottom: 40px;
            margin-top: 50px;
        }
        
        .section-header h2 {
            color: #2c3e50;
            font-size: 32px;
            font-weight: 700;
            position: relative;
            display: inline-block;
            padding-bottom: 15px;
        }
        
        .section-header h2::after {
            content: '';
            position: absolute;
            width: 70px;
            height: 3px;
            background-color: #3498db;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
        }
    </style>
</head>
<body>

<?php
include 'header.php';
include 'connect.php';

// Fetch all departments from database
$departments = [];
$result = $conn->query("SELECT * FROM departments ORDER BY name");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $departments[] = $row;
    }
}
?>

<main class="main-content" style="padding: 40px 20px;">
    <div class="container">
        <div class="section-header">
            <h2>Academic Departments</h2>
        </div>
        
        <div class="department-grid">
            <?php foreach ($departments as $dept): ?>
                <div class="department-card">
                    <div class="department-header">
                        <?php if (!empty($dept['logo_filename'])): ?>
                            <img src="uploads/departments/<?php echo htmlspecialchars($dept['logo_filename']); ?>" 
                                 class="department-logo" alt="<?php echo htmlspecialchars($dept['name']); ?>">
                        <?php else: ?>
                            <div class="department-logo" style="display: flex; align-items: center; justify-content: center;">
                                <span style="font-size: 1.5rem;"><?php echo substr($dept['name'], 0, 1); ?></span>
                            </div>
                        <?php endif; ?>
                        <div>
                            <h3 class="department-title"><?php echo htmlspecialchars($dept['name']); ?></h3>
                            <p class="department-code"><?php echo htmlspecialchars($dept['code']); ?></p>
                        </div>
                    </div>
                    
                    <div class="department-details">
                        <div class="department-detail">
                            <span class="detail-label">Head of Department:</span>
                            <span><?php echo htmlspecialchars($dept['head_name']); ?></span>
                        </div>
                        <div class="department-detail">
                            <span class="detail-label">Total Students:</span>
                            <span><?php echo number_format($dept['total_students']); ?></span>
                        </div>
                        
                        <div class="department-detail description-container">
                            <span class="detail-label">Description:</span>
                            <div class="description-text description-short" 
                                 id="desc-<?php echo $dept['id']; ?>">
                                <?php echo htmlspecialchars($dept['description']); ?>
                            </div>
                            <button class="toggle-description" 
                                    onclick="toggleDescription(<?php echo $dept['id']; ?>)">
                                Show More <i class="fas fa-chevron-down"></i>
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</main>

<?php
include 'footer.php';
?>

<script>
    function toggleMenu() {
        var navLinks = document.getElementById("nav-links");
        navLinks.classList.toggle("active");
    }
    
    function toggleDescription(deptId) {
        const descElement = document.getElementById(`desc-${deptId}`);
        const button = event.currentTarget;
        
        if (descElement.classList.contains('description-short')) {
            // Show full description
            descElement.classList.remove('description-short');
            descElement.classList.add('description-full');
            button.innerHTML = 'Show Less <i class="fas fa-chevron-up"></i>';
        } else {
            // Show short description
            descElement.classList.remove('description-full');
            descElement.classList.add('description-short');
            button.innerHTML = 'Show More <i class="fas fa-chevron-down"></i>';
        }
    }
</script>

</body>
</html>