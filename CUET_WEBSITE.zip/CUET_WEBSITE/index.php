<?php
  include 'admin/connect.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Welcom to CUET</title>
  <link rel="icon" href="logo.png" type="image/png">

  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Knewave&family=My+Soul&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="style.css">
  
</head>
<body>


  <div class="slideshow">
    <img src="1.jpg" alt="Background 1">
    <img src="2.jpg" alt="Background 2">
    <img src="3.jpg" alt="Background 3">
    <img src="4.jpg" alt="Background 4">
  </div>

 

  <?php
    include 'header.php';
  ?>


 
  <div class="content">
    <div class="welcome">
      <h1>Welcome to CUET</h1>
    <p>Explore the green heaven.</p>
    </div>
  </div>

  
  <div class="notices-section">
    <div class="notices-container">
      <h2 class="section-title">📢 Recent Notices</h2>
      
      <div class="notices-grid">
        <?php
        $notice = $conn->query("SELECT * FROM notice ORDER BY date DESC LIMIT 5");
        while($row = $notice->fetch_assoc()):
        ?>
          <div class="notice-card">
            <div class="notice-header">
              <span class="notice-date"><?= date('M d, Y', strtotime($row['date'])) ?></span>
              <?php if(!empty($row['department'])): ?>
                <span class="notice-department"><?= htmlspecialchars($row['department']) ?></span>
              <?php endif; ?>
            </div>
            
            <?php if(!empty($row['title'])): ?>
              <h3 class="notice-title"><?= htmlspecialchars($row['title']) ?></h3>
            <?php endif; ?>
            
            <div class="notice-content">
              <?= nl2br(htmlspecialchars($row['notice'])) ?>
            </div>
            
            <?php if(!empty($row['link'])): ?>
              <div class="notice-footer">
                <a href="<?= htmlspecialchars($row['link']) ?>" class="notice-link" target="_blank">View Details →</a>
              </div>
            <?php endif; ?>
          </div>
        <?php endwhile; ?>
      </div>
    </div>
  </div>





<!-- Add this after the notices-section div -->
<!-- Add this after the notices-section div -->
<div class="stats-section">
    <div class="stats-container">
        <h2 class="section-title">📊 University Statistics</h2>
        
        <div class="stats-grid">
            <?php
            // Get student count
            $student_count = 0;
            $result = $conn->query("SELECT COUNT(*) as total FROM students_info");
            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $student_count = $row['total'];
            }
            
            // Get teacher count
            $teacher_count = 0;
            $result = $conn->query("SELECT COUNT(*) as total FROM teachers_info");
            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $teacher_count = $row['total'];
            }
            
            // Get department count from departments table
            $dept_count = 0;
            $result = $conn->query("SELECT COUNT(*) as total FROM departments");
            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $dept_count = $row['total'];
            }
            ?>
            
            <div class="stat-card">
                <div class="stat-icon">🎓</div>
                <div class="stat-number"><?= number_format($student_count) ?></div>
                <div class="stat-label">Students</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">👨‍🏫</div>
                <div class="stat-number"><?= number_format($teacher_count) ?></div>
                <div class="stat-label">Faculty Members</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">🏛️</div>
                <div class="stat-number"><?= number_format($dept_count) ?></div>
                <div class="stat-label">Departments</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">📚</div>
                <div class="stat-number">85</div>
                <div class="stat-label">Courses Offered</div>
            </div>
        </div>
    </div>
</div>







 
  <?php
    include 'footer.php'
  ?>

  
  <script>
    function toggleMenu() {
      var navLinks = document.getElementById("nav-links");
      navLinks.classList.toggle("active");
    }
  </script>

</body>
</html>