<?php
include 'connect.php';

// Handle delete action
if (isset($_GET['delete'])) {
    $email = $_GET['delete'];
    
    // First delete the photo record if exists
    $sql_delete_photo = "DELETE FROM teacher_photos WHERE email = '" . $conn->real_escape_string($email) . "'";
    $conn->query($sql_delete_photo);
    
    // Then delete the teacher record
    $sql_delete_teacher = "DELETE FROM teachers_info WHERE email = '" . $conn->real_escape_string($email) . "'";
    if ($conn->query($sql_delete_teacher)) {
        // Redirect to avoid resubmission on refresh
        header("Location: teacher_list.php");
        exit();
    }
}

// Get filter values from GET parameters
$selected_department = isset($_GET['department']) ? $_GET['department'] : '';
$selected_designation = isset($_GET['designation']) ? $_GET['designation'] : '';

// Build the SQL query with filters
$sql = "SELECT * FROM teachers_info WHERE 1=1";
if (!empty($selected_department)) {
    $sql .= " AND department = '" . $conn->real_escape_string($selected_department) . "'";
}
if (!empty($selected_designation)) {
    $sql .= " AND designation = '" . $conn->real_escape_string($selected_designation) . "'";
}
$teacher_info = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Teacher List</title>
  <link rel="icon" href="logo.png" type="image/png">
  <link rel="stylesheet" href="teacher_list.css">
  <link rel="stylesheet" href="../style.css">
  <style>
    .filter-container {
      margin: 20px 0;
      display: flex;
      flex-wrap: wrap;
      gap: 15px;
      align-items: center;
    }
    .filter-group {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .filter-group label {
      font-weight: bold;
    }
    .filter-group select {
      padding: 8px;
      border-radius: 4px;
      border: 1px solid #ddd;
    }
    .filter-group button {
      padding: 8px 15px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    .filter-group button:hover {
      background-color: #45a049;
    }
    .reset-btn, .filter_button {
      padding: 8px 15px;
      background-color: #1d75f0;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    .reset-btn:hover {
      background-color: #d32f2f;
    }
    .delete-btn {
      padding: 5px 10px;
      background-color: #f44336;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    .delete-btn:hover {
      background-color: #d32f2f;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    th, td {
      padding: 12px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }
    th {
      background-color: #f2f2f2;
    }
    tr:hover {
      background-color: #f5f5f5;
    }
  </style>
</head>
<body>

<header>
  <div class="logo">
    <img src="logo.png" alt="CUET Logo">
    <h2>CUET</h2>
  </div>
  
  <div class="menu-icon" onclick="toggleMenu()">☰</div>
  
  <nav id="nav-links">
    <a href="../index.php">Home</a>
      <a href="../about.php">About CUET</a>
      <a href="../academic.php">Academic</a>
      <a href="../alumni.php">Alumni</a>
      <a href="../notice.php">Notice</a>
    
    
    <div class="dropdown">
      <a href="#" class="dropbtn">Login</a>
      <div class="dropdown-content">
         <a href="../Login_form/index.php" target="_blank">Student</a>
      <a href="#" >Admin</a>
      
      </div>
    </div>
    <a href="../admin_login/logout.php" target="_blank">Logout</a>
  </nav>
</header>

  <div class="container">
    <h1>Teacher List</h1>
    
    <!-- Filter Form -->
    <form method="get" action="">
      <div class="filter-container">
        <div class="filter-group">
          <label for="department">Department:</label>
          <select name="department" id="department">
            <option value="">All Departments</option>
            <option value="ETE" <?= $selected_department == 'ETE' ? 'selected' : '' ?>>ETE</option>
            <option value="EEE" <?= $selected_department == 'EEE' ? 'selected' : '' ?>>EEE</option>
            <option value="CSE" <?= $selected_department == 'CSE' ? 'selected' : '' ?>>CSE</option>
            <option value="BME" <?= $selected_department == 'BME' ? 'selected' : '' ?>>BME</option>
            <option value="CE" <?= $selected_department == 'CE' ? 'selected' : '' ?>>CE</option>
            <option value="WRE" <?= $selected_department == 'WRE' ? 'selected' : '' ?>>WRE</option>
            <option value="ME" <?= $selected_department == 'ME' ? 'selected' : '' ?>>ME</option>
            <option value="PME" <?= $selected_department == 'PME' ? 'selected' : '' ?>>PME</option>
            <option value="MIE" <?= $selected_department == 'MIE' ? 'selected' : '' ?>>MIE</option>
            <option value="MME" <?= $selected_department == 'MME' ? 'selected' : '' ?>>MME</option>
          </select>
        </div>

        <div class="filter-group">
          <label for="designation">Designation:</label>
          <select name="designation" id="designation">
            <option value="">All Designations</option>
            <option value="Professor" <?= $selected_designation == 'Professor' ? 'selected' : '' ?>>Professor</option>
            <option value="Associate Professor" <?= $selected_designation == 'Associate Professor' ? 'selected' : '' ?>>Associate Professor</option>
            <option value="Assistant Professor" <?= $selected_designation == 'Assistant Professor' ? 'selected' : '' ?>>Assistant Professor</option>
            <option value="Lecturer" <?= $selected_designation == 'Lecturer' ? 'selected' : '' ?>>Lecturer</option>
          </select>
        </div>

        <button type="submit" class="filter_button">Filter</button>
        <a href="teacher_list.php" class="reset-btn">Reset</a>
      </div>
    </form>

    <table>
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Designation</th>
          <th>Contact</th>
          <th>Department</th>
          <th>Portfolio</th>
          <th>Undergrad University</th>
          <th>Photo</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php while($row = $teacher_info->fetch_assoc()): ?>
        <tr>
          <td><?=$row['name'] ?></td>
          <td><?=$row['email'] ?></td>
          <td><?=$row['designation'] ?></td>
          <td><?=$row['contact'] ?></td>
          <td><?=$row['department'] ?></td>
          <td>
            <?php if(!empty($row['portfolio_link'])): ?>
              <a href="<?=$row['portfolio_link'] ?>" target="_blank">View Portfolio</a>
            <?php else: ?>
              N/A
            <?php endif; ?>
          </td>
          <td><?=$row['undergrad_university'] ?></td>
          <td>
            <?php
              if (!empty($row['photo_filename'])) {
                  echo "<img src='uploads/teachers/" . $row['photo_filename'] . "' width='70px' style='margin:1px;'>";
              } else {
                  echo "No photo";
              }
            ?>
          </td>
          <td>
            <button class="delete-btn" onclick="confirmDelete('<?= $row['email'] ?>')">Delete</button>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
  
  <footer>
    <div class="footer-section">
      <h3>Contact Us</h3>
      <p>Pahartoli, Raozan-4349 <br>Chittagong,Bangladesh</p>
      <p>Email: registrar@cuet.ac.bd</p>
      <p>Phone: +88xxxxxxxxx</p>
    </div>

    <div class="footer-section">
      <h3>Useful Links</h3>
      <a href="#home">Home</a>
      <a href="#about">About CUET</a>
      <a href="#academic">Academic</a>
      <a href="#download">Download</a>
      <a href="#download">Login</a>

      <div class="footer-search">
        <input type="text" placeholder="Search...">
        <button>Search</button>
      </div>
      <div><br>
        Copyright Chittagong University of Engineering And Technology
      </div>
    </div>
  </footer>

  <script>
    function toggleMenu() {
      var navLinks = document.getElementById("nav-links");
      navLinks.classList.toggle("active");
    }
    
    function confirmDelete(email) {
      if (confirm("Are you sure you want to delete this teacher?")) {
        window.location.href = "teacher_list.php?delete=" + email;
      }
    }
  </script>
</body>
</html>