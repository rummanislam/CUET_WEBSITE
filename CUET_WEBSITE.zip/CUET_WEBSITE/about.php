<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About CUET</title>
  <link rel="icon" href="logo.png" type="image/png">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="about.css">
  <!-- Add Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
  <style>
    /* Add this style section for the colored fact cards */
    .facts-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
      margin-top: 30px;
    }
    
    .fact-card {
      background: #fff;
      border-radius: 10px;
      padding: 25px;
      text-align: center;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
      border-top: 5px solid #3498db;
    }
    
    /* Color variations for fact cards */
    .fact-card:nth-child(6n+1) {
      border-top-color: #3498db;
      background-color: #e3f2fd;
    }
    .fact-card:nth-child(6n+2) {
      border-top-color: #2ecc71;
      background-color: #e8f5e9;
    }
    .fact-card:nth-child(6n+3) {
      border-top-color: #e74c3c;
      background-color: #ffebee;
    }
    .fact-card:nth-child(6n+4) {
      border-top-color: #f39c12;
      background-color: #fff8e1;
    }
    .fact-card:nth-child(6n+5) {
      border-top-color: #9b59b6;
      background-color: #f3e5f5;
    }
    .fact-card:nth-child(6n+6) {
      border-top-color: #1abc9c;
      background-color: #e0f7fa;
    }
    
    /* Color variations for text to match cards */
    .fact-card:nth-child(6n+1) h3 {
      color: #1976d2;
    }
    .fact-card:nth-child(6n+2) h3 {
      color: #388e3c;
    }
    .fact-card:nth-child(6n+3) h3 {
      color: #d32f2f;
    }
    .fact-card:nth-child(6n+4) h3 {
      color: #ffa000;
    }
    .fact-card:nth-child(6n+5) h3 {
      color: #7b1fa2;
    }
    .fact-card:nth-child(6n+6) h3 {
      color: #0097a7;
    }
    
    .fact-icon {
      font-size: 40px;
      margin-bottom: 15px;
    }
    
    .fact-card h3 {
      margin: 10px 0;
      font-size: 1.2rem;
    }
    
    .fact-card p {
      color: #555;
      line-height: 1.5;
    }
    
    .fact-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    }
  </style>
</head>
<body>

<?php 
include 'header.php';
include 'connect.php'; // Include database connection

// Get VC information from database
$vc_info = [];
$vc_result = $conn->query("SELECT * FROM vc_info LIMIT 1");
if ($vc_result && $vc_result->num_rows > 0) {
    $vc_info = $vc_result->fetch_assoc();
}

// Get history entries from database
$history_entries = [];
$history_result = $conn->query("SELECT * FROM university_history ORDER BY display_order, created_at DESC");
if ($history_result && $history_result->num_rows > 0) {
    while($row = $history_result->fetch_assoc()) {
        $history_entries[] = $row;
    }
}
?>

<main class="about-container">
  <!-- Hero Section -->
  <section class="about-hero">
    <div class="hero-content">
      <h1>About CUET</h1>
      <p>Excellence in Engineering & Technology Education Since 1968</p>
    </div>
  </section>

  <!-- VC Message Section -->
  <section class="vc-section">
    <div class="section-header">
      <h2>Message from the Vice-Chancellor</h2>
      <div class="divider"></div>
    </div>
    
    <?php if(!empty($vc_info)): ?>
    <div class="vc-profile">
      <div class="vc-image">
        <?php if(!empty($vc_info['photo_filename'])): ?>
          <img src="admin/uploads/vc/<?= htmlspecialchars($vc_info['photo_filename']) ?>" alt="<?= htmlspecialchars($vc_info['name']) ?>">
        <?php else: ?>
          <img src="images/default_vc.jpg" alt="Vice-Chancellor">
        <?php endif; ?>
        <div class="vc-info">
          <h3><?= htmlspecialchars($vc_info['name']) ?></h3>
          <p>Vice-Chancellor</p>
        </div>
      </div>
      <div class="vc-message">
        <p><?= nl2br(htmlspecialchars(truncateText($vc_info['message'], 200))) ?></p>
        <a href="#full-message" class="read-more">Read Full Message</a>
      </div>
    </div>
    <?php else: ?>
      <p class="no-data">No VC information available at this time.</p>
    <?php endif; ?>
  </section>

  <!-- History Section -->
  <section class="history-section">
    <div class="section-header">
      <h2>Our History</h2>
      <div class="divider"></div>
    </div>
    
    <?php if(!empty($history_entries)): ?>
      <?php foreach($history_entries as $entry): ?>
        <div class="history-content">
          <?php if(!empty($entry['photo_filename'])): ?>
            <div class="history-image">
              <img src="admin/uploads/history/<?= htmlspecialchars($entry['photo_filename']) ?>" alt="<?= htmlspecialchars($entry['title']) ?>">
            </div>
          <?php endif; ?>
          <div class="history-text">
            <h3><?= htmlspecialchars($entry['title']) ?></h3>
            <p><?= nl2br(htmlspecialchars(truncateText($entry['description'], 300))) ?></p>
            <a href="#full-history-<?= $entry['id'] ?>" class="read-more">Read More</a>
          </div>
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <p class="no-data">No history entries available at this time.</p>
    <?php endif; ?>
  </section>

  <!-- Quick Facts Section -->
  <section class="facts-section">
    <div class="section-header">
      <h2>CUET at a Glance</h2>
      <div class="divider"></div>
    </div>
    
    <div class="facts-grid">
      <div class="fact-card">
        <div class="fact-icon">🏛️</div>
        <h3>Established</h3>
        <p>1968 (as College)<br>2003 (as University)</p>
      </div>
      
      <div class="fact-card">
        <div class="fact-icon">🎓</div>
        <h3>Programs</h3>
        <p>12 Undergraduate<br>18 Postgraduate</p>
      </div>
      
      <div class="fact-card">
        <div class="fact-icon">👨‍🏫</div>
        <h3>Faculty</h3>
        <p>250+ Faculty Members<br>1:20 Teacher-Student Ratio</p>
      </div>
      
      <div class="fact-card">
        <div class="fact-icon">🏫</div>
        <h3>Campus</h3>
        <p>100+ Acre Campus<br>Modern Facilities</p>
      </div>
      
      <div class="fact-card">
        <div class="fact-icon">👨‍🎓</div>
        <h3>Students</h3>
        <p>4000+ Students<br>Active Alumni Network</p>
      </div>
      
      <div class="fact-card">
        <div class="fact-icon">🌐</div>
        <h3>Location</h3>
        <p>Chittagong, Bangladesh<br>Picturesque Surroundings</p>
      </div>
    </div>
  </section>

  <!-- Full Message Modal (hidden by default) -->
  <?php if(!empty($vc_info)): ?>
  <div id="full-message" class="modal">
    <div class="modal-content">
      <a href="#" class="close-modal">&times;</a>
      <h2>Full Message from the Vice-Chancellor</h2>
      <div class="modal-text">
        <h3><?= htmlspecialchars($vc_info['name']) ?></h3>
        <p><?= nl2br(htmlspecialchars($vc_info['message'])) ?></p>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <!-- Full History Modals (hidden by default) -->
  <?php foreach($history_entries as $entry): ?>
  <div id="full-history-<?= $entry['id'] ?>" class="modal">
    <div class="modal-content">
      <a href="#" class="close-modal">&times;</a>
      <h2><?= htmlspecialchars($entry['title']) ?></h2>
      <div class="modal-text">
        <?php if(!empty($entry['photo_filename'])): ?>
          <img src="uploads/history/<?= htmlspecialchars($entry['photo_filename']) ?>" alt="<?= htmlspecialchars($entry['title']) ?>" class="modal-history-image">
        <?php endif; ?>
        <p><?= nl2br(htmlspecialchars($entry['description'])) ?></p>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</main>

<?php include 'footer.php'; ?>

<script>
  function toggleMenu() {
    var navLinks = document.getElementById("nav-links");
    navLinks.classList.toggle("active");
  }

  // Modal functionality
  document.querySelectorAll('.read-more').forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const target = this.getAttribute('href');
      document.querySelector(target).style.display = 'block';
      document.body.style.overflow = 'hidden'; // Prevent scrolling when modal is open
    });
  });

  document.querySelectorAll('.close-modal').forEach(closeBtn => {
    closeBtn.addEventListener('click', function(e) {
      e.preventDefault();
      this.closest('.modal').style.display = 'none';
      document.body.style.overflow = 'auto'; // Re-enable scrolling
    });
  });

  // Close modal when clicking outside
  window.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal')) {
      e.target.style.display = 'none';
      document.body.style.overflow = 'auto';
    }
  });
</script>
</body>
</html>

<?php
// Helper function to truncate text
function truncateText($text, $length) {
    if (strlen($text) <= $length) {
        return $text;
    }
    return substr($text, 0, $length) . '...';
}
?>