<footer>
    <div class="footer-section">
      <h3>Contact Us</h3>
      <p>Pahartoli, Raozan-4349 <br>Chittagong,Bangladesh</p>
      <p>Email: registrar@cuet.ac.bd</p>
      <p>Phone: +88xxxxxxxxx</p>
    </div>

    <div class="footer-section">
      <h3>Useful Links</h3>
      <a href="#home">Home</a>
      <a href="#about">About CUET</a>
      <a href="#academic">Academic</a>
      <a href="#download">Download</a>
      <a href="#download">Login</a>

      <div class="footer-search">
        <input type="text" placeholder="Search...">
        <button>Search</button>
      </div>
      <div><br>
        Copyright Chittagong University of Engineering And Technology
      </div>
    </div>
  </footer>