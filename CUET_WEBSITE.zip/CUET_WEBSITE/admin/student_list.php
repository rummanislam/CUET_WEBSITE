<?php
include 'connect.php';

// Handle delete action
if (isset($_GET['delete'])) {
    $email = $_GET['delete'];
    
    // First delete the photo record if exists
    $sql_delete_photo = "DELETE FROM photos WHERE email = '" . $conn->real_escape_string($email) . "'";
    $conn->query($sql_delete_photo);
    
    // Then delete the student record
    $sql_delete_student = "DELETE FROM students_info WHERE email = '" . $conn->real_escape_string($email) . "'";
    if ($conn->query($sql_delete_student)) {
        // Redirect to avoid resubmission on refresh
        header("Location: student_list.php");
        exit();
    }
}

// Get filter values from GET parameters
$selected_department = isset($_GET['department']) ? $_GET['department'] : '';
$selected_batch = isset($_GET['batch']) ? $_GET['batch'] : '';
$selected_hall = isset($_GET['hall']) ? $_GET['hall'] : '';

// Build the SQL query with filters
$sql = "SELECT * FROM students_info WHERE 1=1";
if (!empty($selected_department)) {
    $sql .= " AND department = '" . $conn->real_escape_string($selected_department) . "'";
}
if (!empty($selected_batch)) {
    $sql .= " AND batch = '" . $conn->real_escape_string($selected_batch) . "'";
}
if (!empty($selected_hall)) {
    $sql .= " AND hall = '" . $conn->real_escape_string($selected_hall) . "'";
}
$student_info = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Student List</title>
  <link rel="icon" href="logo.png" type="image/png">
  <link rel="stylesheet" href="student_list.css">
  <link rel="stylesheet" href="../style.css">
  <style>
    .filter-container {
      margin: 20px 0;
      display: flex;
      flex-wrap: wrap;
      gap: 15px;
      align-items: center;
    }
    .filter-group {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .filter-group label {
      font-weight: bold;
    }
    .filter-group select {
      padding: 8px;
      border-radius: 4px;
      border: 1px solid #ddd;
    }
    .filter-group button {
      padding: 8px 15px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    .filter-group button:hover {
      background-color: #45a049;
    }
    .reset-btn ,.filter_button {
      padding: 8px 15px;
      background-color: #1d75f0;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    .reset-btn:hover {
      background-color: #d32f2f;
    }
    .delete-btn {
      padding: 5px 10px;
      background-color: #f44336;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    .delete-btn:hover {
      background-color: #d32f2f;
    }
  </style>
</head>
<body>

<header>
  <div class="logo">
    <img src="logo.png" alt="CUET Logo">
    <h2>CUET</h2>
  </div>
  
  <div class="menu-icon" onclick="toggleMenu()">☰</div>
  
  <nav id="nav-links">
    <a href="../index.php">Home</a>
      <a href="../about.php">About CUET</a>
      <a href="../academic.php">Academic</a>
      <a href="../alumni.php">Alumni</a>
      <a href="../notice.php">Notice</a>
    
    
    <div class="dropdown">
      <a href="#" class="dropbtn">Login</a>
      <div class="dropdown-content">
         <a href="../Login_form/index.php" target="_blank">Student</a>
      <a href="#" >Admin</a>
      
      </div>
    </div>
    <a href="../admin_login/logout.php" target="_blank">Logout</a>
  </nav>
</header>

  <div class="container">
    <h1>Student List</h1>
    
    <!-- Filter Form -->
    <form method="get" action="">
      <div class="filter-container">
        <div class="filter-group">
          <label for="department">Department:</label>
          <select name="department" id="department">
            <option value="">All Departments</option>
            <option value="ETE" <?= $selected_department == 'ETE' ? 'selected' : '' ?>>ETE</option>
            <option value="EEE" <?= $selected_department == 'EEE' ? 'selected' : '' ?>>EEE</option>
            <option value="CSE" <?= $selected_department == 'CSE' ? 'selected' : '' ?>>CSE</option>
            <option value="BME" <?= $selected_department == 'BME' ? 'selected' : '' ?>>BME</option>
            <option value="CE" <?= $selected_department == 'CE' ? 'selected' : '' ?>>CE</option>
            <option value="WRE" <?= $selected_department == 'WRE' ? 'selected' : '' ?>>WRE</option>
            <option value="ME" <?= $selected_department == 'ME' ? 'selected' : '' ?>>ME</option>
            <option value="PME" <?= $selected_department == 'PME' ? 'selected' : '' ?>>PME</option>
            <option value="MIE" <?= $selected_department == 'MIE' ? 'selected' : '' ?>>MIE</option>
            <option value="MME" <?= $selected_department == 'MME' ? 'selected' : '' ?>>MME</option>
          </select>
        </div>

        <div class="filter-group">
          <label for="batch">Batch:</label>
          <select name="batch" id="batch">
            <option value="">All Batches</option>
            <?php for($i=15; $i<=25; $i++): ?>
              <option value="<?= $i ?>" <?= $selected_batch == $i ? 'selected' : '' ?>><?= $i ?></option>
            <?php endfor; ?>
          </select>
        </div>

        <div class="filter-group">
          <label for="hall">Hall:</label>
          <select name="hall" id="hall">
            <option value="">All Halls</option>
            <option value="KKNIH" <?= $selected_hall == 'KKNIH' ? 'selected' : '' ?>>KKNIH</option>
            <option value="SASH" <?= $selected_hall == 'SASH' ? 'selected' : '' ?>>SASH</option>
            <option value="MSH" <?= $selected_hall == 'MSH' ? 'selected' : '' ?>>MSH</option>
            <option value="QKH" <?= $selected_hall == 'QKH' ? 'selected' : '' ?>>QKH</option>
            <option value="THH" <?= $selected_hall == 'THH' ? 'selected' : '' ?>>THH</option>
            <option value="SNH" <?= $selected_hall == 'SNH' ? 'selected' : '' ?>>SNH</option>
            <option value="SKH" <?= $selected_hall == 'SKH' ? 'selected' : '' ?>>SKH</option>
            <option value="TRH" <?= $selected_hall == 'TRH' ? 'selected' : '' ?>>TRH</option>
          </select>
        </div>

        <button type="submit" class="filter_button">Filter</button>
        <a href="student_list.php" class="reset-btn">Reset</a>
      </div>
    </form>

    <table>
      <thead>
        <tr>
          <th>ID no.</th>
          <th>Name</th>
          <th>Email</th>
          <th>Contact</th>
          <th>Department</th>
          <th>Batch</th>
          <th>Hall</th>
          <th>Photo</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php while($row = $student_info->fetch_assoc()): ?>
        <tr>
          <td><?=$row['id'] ?></td>
          <td><?=$row['name'] ?></td>
          <td><?=$row['email'] ?></td>
          <td><?=$row['contact'] ?></td>
          <td><?=$row['department'] ?></td>
          <td><?=$row['batch'] ?></td>
          <td><?=$row['hall'] ?></td>
          <td>
            <?php
              $sql = "SELECT * FROM photos WHERE email = '" . $row['email'] . "'";
              $result = $conn->query($sql);
              while ($rows = $result->fetch_assoc()) {
                  echo "<img src='uploads/" . $rows['filename'] . "' width='70px' style='margin:1px;'>";
              }
            ?>
          </td>
          <td>
            <button class="delete-btn" onclick="confirmDelete('<?= $row['email'] ?>')">Delete</button>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
  
  <footer>
    <div class="footer-section">
      <h3>Contact Us</h3>
      <p>Pahartoli, Raozan-4349 <br>Chittagong,Bangladesh</p>
      <p>Email: registrar@cuet.ac.bd</p>
      <p>Phone: +88xxxxxxxxx</p>
    </div>

    <div class="footer-section">
      <h3>Useful Links</h3>
      <a href="#home">Home</a>
      <a href="#about">About CUET</a>
      <a href="#academic">Academic</a>
      <a href="#download">Download</a>
      <a href="#download">Login</a>

      <div class="footer-search">
        <input type="text" placeholder="Search...">
        <button>Search</button>
      </div>
      <div><br>
        Copyright Chittagong University of Engineering And Technology
      </div>
    </div>
  </footer>

  <script>
    function toggleMenu() {
      var navLinks = document.getElementById("nav-links");
      navLinks.classList.toggle("active");
    }
    
    function confirmDelete(email) {
      if (confirm("Are you sure you want to delete this student?")) {
        window.location.href = "student_list.php?delete=" + email;
      }
    }
  </script>
</body>
</html>