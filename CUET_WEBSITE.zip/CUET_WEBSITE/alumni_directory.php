<?php
// Database connection
// $db = new mysqli('localhost', 'username', 'password', 'database_name');
include 'connect.php';
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get alumni list
$sql = "SELECT * FROM alumni ORDER BY batch DESC, name ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Directory | CUET</title>
    <link rel="icon" href="logo.png" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        .directory-container {
            max-width: 1200px;
            margin: 50px auto;
            padding: 30px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        .directory-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .directory-header h2 {
            color: #2c3e50;
            margin-bottom: 10px;
        }
        .search-box {
            margin-bottom: 30px;
        }
        .search-box input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        .alumni-table {
            width: 100%;
            border-collapse: collapse;
        }
        .alumni-table th, .alumni-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .alumni-table th {
            background-color: #3498db;
            color: white;
        }
        .alumni-table tr:hover {
            background-color: #f5f5f5;
        }
        .batch-header {
            background-color: #f8f9fa;
            font-weight: bold;
            padding: 10px 15px;
            margin-top: 20px;
        }
        .no-alumni {
            text-align: center;
            padding: 30px;
            color: #7f8c8d;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <div class="directory-container">
            <div class="directory-header">
                <h2><i class="fas fa-address-book"></i> CUET Alumni Directory</h2>
                <p>Connect with fellow graduates from Chittagong University of Engineering and Technology</p>
            </div>
            
            <div class="search-box">
                <input type="text" id="searchInput" placeholder="Search alumni by name, batch, or current status...">
            </div>
            
            <?php if ($result->num_rows > 0): ?>
                <table class="alumni-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Student ID</th>
                            <th>Batch</th>
                            <th>Hall</th>
                            <th>Current Status</th>
                            <th>Living Place</th>
                        </tr>
                    </thead>
                    <tbody id="alumniTableBody">
                        <?php 
                        $current_batch = '';
                        while ($row = $result->fetch_assoc()): 
                            if ($row['batch'] != $current_batch) {
                                $current_batch = $row['batch'];
                                echo '<tr class="batch-header"><td colspan="6">Batch: ' . htmlspecialchars($current_batch) . '</td></tr>';
                            }
                        ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['name']); ?></td>
                                <td><?php echo htmlspecialchars($row['student_id']); ?></td>
                                <td><?php echo htmlspecialchars($row['batch']); ?></td>
                                <td><?php echo htmlspecialchars($row['hall']); ?></td>
                                <td><?php echo htmlspecialchars($row['current_status']); ?></td>
                                <td><?php echo htmlspecialchars($row['living_place']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-alumni">
                    <i class="fas fa-user-friends fa-3x"></i>
                    <h3>No alumni registered yet</h3>
                    <p>Be the first to register as an alumni!</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php include 'footer.php'; ?>
    
    <script>
        // Search functionality
        document.getElementById('searchInput').addEventListener('keyup', function() {
            const searchValue = this.value.toLowerCase();
            const rows = document.querySelectorAll('#alumniTableBody tr:not(.batch-header)');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                if (text.includes(searchValue)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
            
            // Show/hide batch headers based on visible rows
            const batchHeaders = document.querySelectorAll('.batch-header');
            batchHeaders.forEach(header => {
                let hasVisibleRows = false;
                let nextRow = header.nextElementSibling;
                
                while (nextRow && !nextRow.classList.contains('batch-header')) {
                    if (nextRow.style.display !== 'none') {
                        hasVisibleRows = true;
                        break;
                    }
                    nextRow = nextRow.nextElementSibling;
                }
                
                header.style.display = hasVisibleRows ? '' : 'none';
            });
        });
    </script>
</body>
</html>