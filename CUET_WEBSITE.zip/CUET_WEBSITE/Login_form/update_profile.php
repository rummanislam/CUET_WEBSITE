<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['email'])) {
    header("Location: ../Login_form/index.php");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_SESSION['email'];
    $name = $_POST['name'];
    $contact = $_POST['contact'];
    $hall = $_POST['hall'];
    
    // Update basic info
    $update_query = "UPDATE students_info SET name=?, contact=?, hall=? WHERE email=?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("ssss", $name, $contact, $hall, $email);
    $stmt->execute();
    
    // Handle photo upload
    if (!empty($_FILES['photo']['name'])) {
        // First, delete the existing photo if it exists
        $existing_query = mysqli_query($conn, "SELECT filename FROM photos WHERE email = '$email'");
        if ($existing_photo = mysqli_fetch_assoc($existing_query)) {
            $old_file_path = "../admin/uploads/" . $existing_photo['filename'];
            if (file_exists($old_file_path)) {
                unlink($old_file_path); // Delete the file from server
            }
            // Delete the record from database
            mysqli_query($conn, "DELETE FROM photos WHERE email = '$email'");
        }

        // Process new photo upload
        $target_dir = "../admin/uploads/";
        $target_file = $target_dir . basename($_FILES["photo"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        
        // Check if image file is a actual image
        $check = getimagesize($_FILES["photo"]["tmp_name"]);
        if ($check !== false) {
            // Generate unique filename
            $new_filename = uniqid() . '.' . $imageFileType;
            $target_file = $target_dir . $new_filename;
            
            // Move uploaded file
            if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
                // Insert new photo record
                $photo_query = "INSERT INTO photos (email, filename) VALUES (?, ?)";
                $stmt = $conn->prepare($photo_query);
                $stmt->bind_param("ss", $email, $new_filename);
                $stmt->execute();
            }
        }
    }
    
    $_SESSION['success'] = "Profile updated successfully!";
    header("Location: update_profile.php");
    exit();
}

// Get current student info
$email = $_SESSION['email'];
$query = mysqli_query($conn, "SELECT * FROM students_info WHERE email = '$email'");
$student_info = mysqli_fetch_assoc($query);

// Get current photo
$photo_query = mysqli_query($conn, "SELECT filename FROM photos WHERE email = '$email'");
$photo = mysqli_fetch_assoc($photo_query);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile - Student Panel</title>
    <link rel="icon" href="logo.png" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link href="../style.css" rel="stylesheet">
    <style>
        :root {
            --sidebar-width: 250px;
            --header-height: 80px;
            --footer-height: 100px;
            --primary-color: #2c3e50;
            --secondary-color: #4275f5;
            --light-gray: #f5f5f5;
            --dark-gray: #333;
            --border-color: #ddd;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Roboto', sans-serif;
        }
        
        body {
            background-color: var(--light-gray);
            color: var(--dark-gray);
            padding-top: var(--header-height);
            padding-bottom: var(--footer-height);
            min-height: 100vh;
            position: relative;
        }
        
        /* Header Styles (front position) */
        header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: var(--header-height);
            background: var(--primary-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            z-index: 1002; /* Higher than sidebar */
        }
        
        /* Sidebar Styles (behind header/footer) */
        .sidebar {
            position: fixed;
            top: var(--header-height);
            left: 0;
            width: var(--sidebar-width);
            /* height: calc(100vh - var(--header-height) - var(--footer-height)); */
            background: var(--primary-color);
            color: white;
            padding: 20px 0;
            overflow-y: auto;
            transition: transform 0.3s ease;
            z-index: 900; /* Lower than header/footer */
            height: 100%;
        }
        
        .sidebar h2 {
            padding: 0 20px 15px;
            border-bottom: 1px solid #34495e;
        }
        
        .sidebar-menu {
            list-style: none;
        }
        
        .sidebar-menu li {
            padding: 12px 20px;
            border-bottom: 1px solid #34495e;
            transition: background 0.3s;
        }
        
        .sidebar-menu li:hover {
            background: #34495e;
        }
        
        .sidebar-menu li a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .sidebar-menu li.active {
            background: #34495e;
        }
        
        /* Main Content Styles */
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 30px;
            transition: margin-left 0.3s ease;
        }
        
        .page-title {
            margin-bottom: 30px;
            color: var(--primary-color);
        }
        
        /* Form Styles */
        .update-form {
            background: white;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            max-width: 900px;
            margin: 0 auto;
        }
        
        .form-row {
            display: flex;
            gap: 30px;
            margin-bottom: 20px;
        }
        
        .form-col {
            flex: 1;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            font-size: 16px;
        }
        
        .photo-section {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .photo-preview {
            width: 180px;
            height: 180px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--border-color);
            margin-bottom: 20px;
        }
        
        .file-input {
            display: none;
        }
        
        .file-label {
            display: inline-block;
            padding: 10px 15px;
            background: var(--secondary-color);
            color: white;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .file-label:hover {
            background: #315fd1;
        }
        
        .submit-btn {
            background: var(--secondary-color);
            color: white;
            border: none;
            padding: 12px 25px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s;
            display: block;
            margin: 30px auto 0;
            width: 200px;
        }
        
        .submit-btn:hover {
            background: #315fd1;
        }
        
        .success-message {
            color: #28a745;
            text-align: center;
            margin-bottom: 20px;
            padding: 10px;
            background: #d4edda;
            border-radius: 4px;
        }





        
        /* Footer Placeholder */
        .footer-placeholder {
            height: 100px;
        }
        
        /* Responsive Styles */
        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .form-row {
                flex-direction: column;
                gap: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Header Placeholder -->
    <div class="header-placeholder">
        <?php
        include 'header.php';
        ?>
    </div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <h2>Student Panel</h2>
        <ul class="sidebar-menu">
            <li>
                <a href="student_dashboard.php">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </li>
            <li class="active">
                <a href="update_profile.php">
                    <i class="fas fa-user-edit"></i> Update Profile
                </a>
            </li>
            <li>
                <a href="course_registration.php">
                    <i class="fas fa-book"></i> Course Registration
                </a>
            </li>
            <li>
                <a href="student_dashboard.php#student-result">
                    <i class="fas fa-chart-bar"></i> Results
                </a>
            </li>
            <!-- <li>
                <a href="class_routine.php">
                    <i class="fas fa-calendar-alt"></i> Class Routine
                </a>
            </li> -->
            <li>
                <a href="logout.php">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <main class="main-content" id="main-content">
        <h1 class="page-title">Update Profile</h1>
        
        <div class="update-form">
            <?php if (isset($_SESSION['success'])): ?>
                <div class="success-message">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
            <?php endif; ?>
            
            <form action="update_profile.php" method="POST" enctype="multipart/form-data">
                <div class="form-row">
                    <div class="form-col">
                        <div class="form-group">
                            <label for="name">Full Name</label>
                            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($student_info['name'] ?? ''); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="contact">Contact Number</label>
                            <input type="text" id="contact" name="contact" value="<?php echo htmlspecialchars($student_info['contact'] ?? ''); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="hall">Hall</label>
                            <select id="hall" name="hall" required>
                                <option value="">Select Hall</option>
                                <option value="KKNIH" <?php echo ($student_info['hall'] ?? '') == 'KKNIH' ? 'selected' : ''; ?>>KKNIH</option>
                                <option value="SASH" <?php echo ($student_info['hall'] ?? '') == 'SASH' ? 'selected' : ''; ?>>SASH</option>
                                <option value="MSH" <?php echo ($student_info['hall'] ?? '') == 'MSH' ? 'selected' : ''; ?>>MSH</option>
                                <option value="QKH" <?php echo ($student_info['hall'] ?? '') == 'QKH' ? 'selected' : ''; ?>>QKH</option>
                                <option value="THH" <?php echo ($student_info['hall'] ?? '') == 'THH' ? 'selected' : ''; ?>>THH</option>
                                <option value="SNH" <?php echo ($student_info['hall'] ?? '') == 'SNH' ? 'selected' : ''; ?>>SNH</option>
                                <option value="SKH" <?php echo ($student_info['hall'] ?? '') == 'SKH' ? 'selected' : ''; ?>>SKH</option>
                                <option value="TRH" <?php echo ($student_info['hall'] ?? '') == 'TRH' ? 'selected' : ''; ?>>TRH</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-col photo-section">
                        <?php if (!empty($photo['filename'])): ?>
                            <img src="../admin/uploads/<?php echo htmlspecialchars($photo['filename']); ?>" class="photo-preview" id="photoPreview">
                        <?php else: ?>
                            <img src="../admin/uploads/default.jpg" class="photo-preview" id="photoPreview">
                        <?php endif; ?>
                        
                        <input type="file" id="photo" name="photo" accept="image/*" class="file-input" onchange="previewImage(this)">
                        <label for="photo" class="file-label">
                            <i class="fas fa-camera"></i> Change Photo
                        </label>
                    </div>
                </div>
                
                <button type="submit" class="submit-btn">Update Profile</button>
            </form>
        </div>
    </main>

    <!-- Footer Placeholder -->
    <div class="footer-placeholder">

    <?php
        // include 'footer.php';
    ?>
    </div>

    <script>
        // Toggle sidebar function
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('active');
        }

        // Preview uploaded image
        function previewImage(input) {
            const preview = document.getElementById('photoPreview');
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        // Ensure sidebar is visible on desktop when resizing
        window.addEventListener('resize', function() {
            const sidebar = document.getElementById('sidebar');
            if (window.innerWidth > 992) {
                sidebar.classList.remove('active');
            }
        });


        // document.getElementById('photo').addEventListener('change', function(e) {
        //     const preview = document.getElementById('photoPreview');
        //     const currentSrc = preview.src;
            
        //     if (this.files && this.files[0]) {
        //         if (currentSrc.includes('default.jpg') || confirm('Are you sure you want to replace the current photo?')) {
        //             const reader = new FileReader();
        //             reader.onload = function(e) {
        //                 preview.src = e.target.result;
        //             }
        //             reader.readAsDataURL(this.files[0]);
        //         } else {
        //             this.value = ''; // Clear the file input
        //         }
        //     }
        // });


        // Enhanced photo upload with preview
        function previewImage(input) {
            const preview = document.getElementById('photoPreview');
            if (input.files && input.files[0]) {
                // Ask for confirmation if replacing existing photo
                if (!preview.src.includes('default.jpg') && !confirm('Are you sure you want to replace the current photo?')) {
                    input.value = ''; // Clear the file input
                    return;
                }
                
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

    </script>
</body>
</html>