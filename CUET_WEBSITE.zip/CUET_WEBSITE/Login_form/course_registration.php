<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['email'])) {
    header("Location: ../Login_form/index.php");
    exit();
}

// Get student info
$email = $_SESSION['email'];
$student_info = $conn->query("SELECT * FROM students_info WHERE email='$email'")->fetch_assoc();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_registration'])) {
    $level_term = $_POST['level_term'];
    $payment_method = $_POST['payment_method'];
    $transaction_id = $_POST['transaction_id'];
    $course_fee = $_POST['course_fee'];
    
    $conn->query("INSERT INTO course_registrations (
        student_email, 
        student_id, 
        student_name, 
        department, 
        batch, 
        hall, 
        level_term, 
        payment_method, 
        transaction_id,
        course_fee
    ) VALUES (
        '$email',
        '{$student_info['id']}',
        '{$student_info['name']}',
        '{$student_info['department']}',
        '{$student_info['batch']}',
        '{$student_info['hall']}',
        '$level_term',
        '$payment_method',
        '$transaction_id',
        '$course_fee'
    )");
    
    header("Location: course_registration.php");
    exit();
}

// Check if student has pending or approved registration
$registration_status = $conn->query("SELECT status FROM course_registrations WHERE student_email='$email' ORDER BY registration_date DESC LIMIT 1")->fetch_assoc();

// Get all registered level/terms for this student
$registered_terms = [];
$result = $conn->query("SELECT level_term FROM course_registrations WHERE student_email='$email'");
while ($row = $result->fetch_assoc()) {
    $registered_terms[] = $row['level_term'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Registration</title>
    <link rel="icon" href="logo.png" type="image/png">
    <link rel="stylesheet" href="../style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .registration-container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-top: 10px;
        }
        
        .registration-form {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        .form-group input, .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .form-group.full-width {
            grid-column: span 2;
        }
        
        .btn {
            padding: 10px 15px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .status-pending {
            color: #FF9800;
            font-weight: bold;
        }
        
        .status-approved {
            color: #4CAF50;
            font-weight: bold;
        }
        
        .download-btn {
            background: #2196F3;
        }

        /* Registration status table styles */
        .registration-status {
            width: 100%;
            margin-bottom: 20px;
            border-collapse: collapse;
        }
        
        .registration-status th, .registration-status td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
        }
        
        .registration-status th {
            background-color: #f2f2f2;
        }
        
        .registered {
            color: #4CAF50;
        }
        
        .not-registered {
            color: #f44336;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            height: calc(100vh - 80px); /* Subtract header height */
            background: #2c3e50;
            position: fixed;
            top: 80px; /* Below header */
            left: 0;
            z-index: 900; /* Lower than header */
            padding-top: 20px;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
            overflow-y: auto;
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-menu li {
            padding: 15px;
            border-bottom: 1px solid #34495e;
            transition: all 0.3s;
        }

        .sidebar-menu li:hover {
            background: #34495e;
        }

        .sidebar-menu li a {
            color: #ecf0f1;
            text-decoration: none;
            display: block;
            font-size: 16px;
        }

        .sidebar-menu li a i {
            margin-right: 10px;
        }

        .sidebar-toggle {
            position: fixed;
            left: 20px;
            top: 20px;
            z-index: 1100;
            font-size: 24px;
            color: white;
            cursor: pointer;
            background: #2c3e50;
            padding: 10px;
            border-radius: 50%;
            display: none;
        }
       
        .main-content {
            margin-left: 280px;
            transition: margin-left 0.3s ease;
            padding: 20px;
            margin-top: 80px; /* Account for header height */
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                top: 80px; /* Below header */
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .sidebar-toggle {
                display: block;
            }
            .main-content {
                margin-left: 0;
            }
        }

        /* Header styles */
        header {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000; /* Higher than sidebar */
            left: 0;
            height: 80px;
            background: #2c3e50;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        footer{
          z-index: 1000;
          position: relative;
        }

        @media (min-width: 769px) {
            header {
                left: 0;
                width: 100%;
                padding-left: 270px; /* Account for sidebar */
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar Toggle Button (Mobile only) -->
    <div class="sidebar-toggle" onclick="toggleSidebar()">
        ☰
    </div>

    <!-- Header -->


        <header>
  <div class="logo">
    <img src="logo.png" alt="CUET Logo">
    <h2>CUET</h2>
  </div>
  
  <div class="menu-icon" onclick="toggleMenu()">☰</div>
  
  <nav id="nav-links">
    <a href="../index.php">Home</a>
    <a href="../about.html">About CUET</a>
    <a href="../academic.html">Academic</a>
    <a href="../alumni.html">Alumni</a>
    <a href="../notice.php">Notice</a>
    
    
    <div class="dropdown">
      <a href="#" class="dropbtn">Login</a>
      <div class="dropdown-content">
         <a href="../Login_form/index.php">Student</a>
        <a href="../admin_login/index.php">Admin</a>
      
      </div>
    </div>
    <a href="logout.php">Logout</a>
  </nav>
</header>













<!-- 
    <header>
        <div class="logo">
          <img src="logo.png" alt="CUET Logo">
          <div style="color:white;"><h2>CUET</h2></div>
        </div>
    
        <div class="menu-icon" onclick="toggleMenu()">☰</div>
    
        <nav id="nav-links">
          <a href="../index.php">Home</a>
          <a href="../about.html">About CUET</a>
          <a href="../academic.html">Academic</a>
          <a href="../alumni.html">Alumni</a>
          <a href="../notice.php">Notice</a>
          <a href="../Login_form/index.php">Student Login</a>
          <a href="../admin_login/index.php">Admin</a>
          <a href="logout.php">Logout</a>
        </nav>
    </header> -->

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <h2 style="color: white; margin-left: 20px;">Student Panel</h2>
        <ul class="sidebar-menu">
            <li>
                <a href="student_dashboard.php">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </li>
            <li>
                <a href="update_profile.php">
                    <i class="fas fa-user-edit"></i> Update Profile
                </a>
            </li>
            <li>
                <a href="course_registration.php">
                    <i class="fas fa-book"></i> Course Registration
                </a>
            </li>
            <li>
                <a href="student_dashboard.php#student-result">
                    <i class="fas fa-chart-bar"></i> Results
                </a>
            </li>
            
            <!-- <li>
                <a href=" class_routine.php">
                    <i class="fas fa-calendar-alt"></i> Class Routine
                </a>
            </li> -->
            
            <li>
                <a href="logout.php">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </li>
        </ul>
    </div>
    
    <main class="main-content">
        <div class="registration-container">
            <h2>Current Status:</h2>
            <!-- Registration Status Table -->
            <table class="registration-status">
                <thead>
                    <tr>
                        <th>Level 1 Term 1</th>
                        <th>Level 1 Term 2</th>
                        <th>Level 2 Term 1</th>
                        <th>Level 2 Term 2</th>
                        <th>Level 3 Term 1</th>
                        <th>Level 3 Term 2</th>
                        <th>Level 4 Term 1</th>
                        <th>Level 4 Term 2</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo in_array('Level 1 Term 1', $registered_terms) ? '<i class="fas fa-check registered"></i>' : '<i class="fas fa-times not-registered"></i>'; ?></td>
                        <td><?php echo in_array('Level 1 Term 2', $registered_terms) ? '<i class="fas fa-check registered"></i>' : '<i class="fas fa-times not-registered"></i>'; ?></td>
                        <td><?php echo in_array('Level 2 Term 1', $registered_terms) ? '<i class="fas fa-check registered"></i>' : '<i class="fas fa-times not-registered"></i>'; ?></td>
                        <td><?php echo in_array('Level 2 Term 2', $registered_terms) ? '<i class="fas fa-check registered"></i>' : '<i class="fas fa-times not-registered"></i>'; ?></td>
                        <td><?php echo in_array('Level 3 Term 1', $registered_terms) ? '<i class="fas fa-check registered"></i>' : '<i class="fas fa-times not-registered"></i>'; ?></td>
                        <td><?php echo in_array('Level 3 Term 2', $registered_terms) ? '<i class="fas fa-check registered"></i>' : '<i class="fas fa-times not-registered"></i>'; ?></td>
                        <td><?php echo in_array('Level 4 Term 1', $registered_terms) ? '<i class="fas fa-check registered"></i>' : '<i class="fas fa-times not-registered"></i>'; ?></td>
                        <td><?php echo in_array('Level 4 Term 2', $registered_terms) ? '<i class="fas fa-check registered"></i>' : '<i class="fas fa-times not-registered"></i>'; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="registration-container">
            <h2 style="text-align: center;">Course Registration Form</h2><br>
            
            
            
            <?php if (isset($registration_status['status'])): ?>
                <?php if ($registration_status['status'] == 'pending'): ?>
                    <div class="status-pending">
                        <p>Your registration is pending for approval.</p>
                    </div>
                    <?php else: ?>
    <div class="status-approved">
        <p>Your registration has been approved!</p>
        <div style="display: flex; gap: 10px; margin-top: 10px;">
            <a href="generate_pdf.php"><button class="btn download-btn">Download Registration Form</button></a>
            <a href="course_registration.php?new_registration=true"><button class="btn" style="background: #ff9800;">New Registration</button></a>
        </div>
    </div>
<?php endif; ?>
            <?php else: ?>
                <form class="registration-form" method="POST" action="">
                    <div class="form-group">
                        <label>Name:</label>
                        <input type="text" value="<?= htmlspecialchars($student_info['name']) ?>" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label>ID:</label>
                        <input type="text" value="<?= htmlspecialchars($student_info['id']) ?>" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label>Email:</label>
                        <input type="email" value="<?= htmlspecialchars($student_info['email']) ?>" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label>Contact:</label>
                        <input type="text" value="<?= htmlspecialchars($student_info['contact']) ?>" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label>Department:</label>
                        <input type="text" value="<?= htmlspecialchars($student_info['department']) ?>" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label>Batch:</label>
                        <input type="text" value="<?= htmlspecialchars($student_info['batch']) ?>" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label>Hall:</label>
                        <input type="text" value="<?= htmlspecialchars($student_info['hall']) ?>" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label>Level & Term:</label>
                        <select name="level_term" required>
                            <option value="">Select Level & Term</option>
                            <option value="Level 1 Term 1">Level 1 Term 1</option>
                            <option value="Level 1 Term 2">Level 1 Term 2</option>
                            <option value="Level 2 Term 1">Level 2 Term 1</option>
                            <option value="Level 2 Term 2">Level 2 Term 2</option>
                            <option value="Level 3 Term 1">Level 3 Term 1</option>
                            <option value="Level 3 Term 2">Level 3 Term 2</option>
                            <option value="Level 4 Term 1">Level 4 Term 1</option>
                            <option value="Level 4 Term 2">Level 4 Term 2</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Payment Method:</label>
                        <select name="payment_method" required>
                            <option value="">Select Payment Method</option>
                            <option value="bKash">bKash</option>
                            <option value="Nagad">Nagad</option>
                            <option value="Rocket">Rocket</option>
                            <option value="Sonali Bank">Sonali Bank</option>
                        </select>
                    </div>
                    <div class="form-group">
    <label>Course Fee (BDT):</label>
    <input type="number" name="course_fee" min="0" step="0.01" required>
</div>
                    
                    <div class="form-group full-width">
                        <label>Transaction ID:</label>
                        <input type="text" name="transaction_id" required>
                    </div>
                    
                    <div class="form-group full-width">
                        <button type="submit" name="submit_registration" class="btn">Submit Registration</button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </main>

    <script>
        // Toggle sidebar function (Mobile only)
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('active');
        }

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(event) {
            const sidebar = document.getElementById('sidebar');
            const sidebarToggle = document.querySelector('.sidebar-toggle');
            const isClickInsideSidebar = sidebar.contains(event.target);
            const isClickOnToggle = sidebarToggle.contains(event.target);
            
            if (window.innerWidth <= 768 && !isClickInsideSidebar && !isClickOnToggle && sidebar.classList.contains('active')) {
                sidebar.classList.remove('active');
            }
        });

        // Existing toggle menu function
        function toggleMenu() {
            var navLinks = document.getElementById("nav-links");
            navLinks.classList.toggle("active");
        }

        // Ensure sidebar is visible on desktop when resizing
        window.addEventListener('resize', function() {
            const sidebar = document.getElementById('sidebar');
            if (window.innerWidth > 768) {
                sidebar.classList.remove('active');
            }
        });

        if (window.location.search.includes('new_registration=true')) {
        // Create a form element
        const form = document.createElement('form');
        form.className = 'registration-form';
        form.method = 'POST';
        form.action = '';
        form.innerHTML = `
            <!-- Your existing form HTML goes here -->
            <div class="form-group">
                        <label>Name:</label>
                        <input type="text" value="<?= htmlspecialchars($student_info['name']) ?>" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label>ID:</label>
                        <input type="text" value="<?= htmlspecialchars($student_info['id']) ?>" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label>Email:</label>
                        <input type="email" value="<?= htmlspecialchars($student_info['email']) ?>" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label>Contact:</label>
                        <input type="text" value="<?= htmlspecialchars($student_info['contact']) ?>" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label>Department:</label>
                        <input type="text" value="<?= htmlspecialchars($student_info['department']) ?>" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label>Batch:</label>
                        <input type="text" value="<?= htmlspecialchars($student_info['batch']) ?>" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label>Hall:</label>
                        <input type="text" value="<?= htmlspecialchars($student_info['hall']) ?>" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label>Level & Term:</label>
                        <select name="level_term" required>
                            <option value="">Select Level & Term</option>
                            <option value="Level 1 Term 1">Level 1 Term 1</option>
                            <option value="Level 1 Term 2">Level 1 Term 2</option>
                            <option value="Level 2 Term 1">Level 2 Term 1</option>
                            <option value="Level 2 Term 2">Level 2 Term 2</option>
                            <option value="Level 3 Term 1">Level 3 Term 1</option>
                            <option value="Level 3 Term 2">Level 3 Term 2</option>
                            <option value="Level 4 Term 1">Level 4 Term 1</option>
                            <option value="Level 4 Term 2">Level 4 Term 2</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Payment Method:</label>
                        <select name="payment_method" required>
                            <option value="">Select Payment Method</option>
                            <option value="bKash">bKash</option>
                            <option value="Nagad">Nagad</option>
                            <option value="Rocket">Rocket</option>
                            <option value="Sonali Bank">Sonali Bank</option>
                        </select>
                    </div>
                    <div class="form-group">
    <label>Course Fee (BDT):</label>
    <input type="number" name="course_fee" min="0" step="0.01" required>
</div>
                    
                    <div class="form-group full-width">
                        <label>Transaction ID:</label>
                        <input type="text" name="transaction_id" required>
                    </div>
                    
                    <div class="form-group full-width">
                        <button type="submit" name="submit_registration" class="btn">Submit Registration</button>
                    </div>
        `;
        
        // Replace the status-approved div with the form
        document.querySelector('.status-approved').replaceWith(form);
    }
    </script>
</body>
</html>