<footer>
    <div class="footer-section">
      <h3>Contact Us</h3>
      <p>Pahartoli, Raozan-4349 <br>Chittagong,Bangladesh</p>
      <p>Email: registrar@cuet.ac.bd</p>
      <p>Phone: +88xxxxxxxxx</p>
    </div>

    <div class="footer-section">
      <h3>Useful Links</h3>
      <a href="../index.php">Home</a>
  <a href="../about.php">About CUET</a>
  <a href="../academic.php">Academic</a>
  <a href="../alumni.php">Alumni</a>
  <a href="../notice.php">Notice</a>

      <div><br>
        @Copyright Chittagong University of Engineering And Technology
      </div>
    </div>
  </footer>