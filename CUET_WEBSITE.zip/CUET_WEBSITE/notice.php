<?php
  include 'admin/connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>University Notice Board</title>
  <link rel="icon" href="logo.png" type="image/png">
  <link rel="stylesheet" href="notice.css">
  <link rel="stylesheet" href="style.css">
  <link rel="icon" href="favicon.png" type="image/png">
  <style>
    /* Notice Cards with Different Colors */
    .notices-container {
      display: flex;
      flex-direction: column;
      gap: 25px;
      margin-top: 30px;
      max-width: 800px; /* Optional: Set a max-width for better readability */
      margin-left: auto;
      margin-right: auto;
    }
    
    .notice-card {
      background: #fff;
      border-radius: 8px;
      padding: 25px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
      transition: all 0.3s ease;
      border-left: 5px solid #3498db;
      width: 100%; /* Ensure cards take full width of container */
    }
    
    /* Color variations for notice cards - now using nth-of-type instead of nth-child */
    .notice-card:nth-of-type(6n+1) {
      border-left-color: #3498db;
      background-color: #e3f2fd;
    }
    .notice-card:nth-of-type(6n+2) {
      border-left-color: #2ecc71;
      background-color: #e8f5e9;
    }
    .notice-card:nth-of-type(6n+3) {
      border-left-color: #e74c3c;
      background-color: #ffebee;
    }
    .notice-card:nth-of-type(6n+4) {
      border-left-color: #f39c12;
      background-color: #fff8e1;
    }
    .notice-card:nth-of-type(6n+5) {
      border-left-color: #9b59b6;
      background-color: #f3e5f5;
    }
    .notice-card:nth-of-type(6n+6) {
      border-left-color: #1abc9c;
      background-color: #e0f7fa;
    }
    
    /* Department tag colors */
    .notice-department {
      display: inline-block;
      padding: 3px 10px;
      border-radius: 15px;
      font-size: 0.8rem;
      font-weight: 500;
    }
    
    .notice-card:nth-of-type(6n+1) .notice-department {
      background-color: #bbdefb;
      color: #0d47a1;
    }
    .notice-card:nth-of-type(6n+2) .notice-department {
      background-color: #c8e6c9;
      color: #1b5e20;
    }
    .notice-card:nth-of-type(6n+3) .notice-department {
      background-color: #ffcdd2;
      color: #b71c1c;
    }
    .notice-card:nth-of-type(6n+4) .notice-department {
      background-color: #ffe0b2;
      color: #e65100;
    }
    .notice-card:nth-of-type(6n+5) .notice-department {
      background-color: #e1bee7;
      color: #4a148c;
    }
    .notice-card:nth-of-type(6n+6) .notice-department {
      background-color: #b2ebf2;
      color: #006064;
    }
    
    /* Rest of your existing styles remain the same */
    .notice-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 15px;
    }
    
    .notice-date {
      color: #666;
      font-size: 0.9rem;
    }
    
    .notice-title {
      color: #2c3e50;
      margin: 10px 0 15px;
      font-size: 1.2rem;
    }
    
    .notice-content {
      color: #555;
      line-height: 1.6;
      margin-bottom: 15px;
    }
    
    .notice-link {
      color: #3498db;
      text-decoration: none;
      font-weight: 500;
      transition: color 0.3s;
    }
    
    .notice-link:hover {
      color: #2980b9;
      text-decoration: underline;
    }
    
    .notice-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    }
</style>
</head>
<body>

<?php
   include 'header.php';
?>

<div class="marquee-container">
  <div class="marquee">
    <?php
    $imp_notice = $conn->query("SELECT * FROM important_notice ORDER BY date DESC");
    while($row = $imp_notice->fetch_assoc()):
    ?>
      <span><?= htmlspecialchars($row['notice']) ?></span>
    <?php endwhile; ?>
    
    <?php
    // Duplicate items for seamless looping
    $imp_notice = $conn->query("SELECT * FROM important_notice ORDER BY date DESC");
    while($row = $imp_notice->fetch_assoc()):
    ?>
      <span><?= htmlspecialchars($row['notice']) ?></span>
    <?php endwhile; ?>
  </div>
</div>

<main class="container">
  <h2 class="section-title">📢 Recent Notices</h2>
  
  <div class="notices-container">
    <?php
    $notice = $conn->query("SELECT * FROM notice ORDER BY date DESC");
    while($row = $notice->fetch_assoc()):
    ?>
      <div class="notice-card">
        <div class="notice-header">
          <span class="notice-date"><?= date('M d, Y', strtotime($row['date'])) ?></span>
          <?php if(!empty($row['department'])): ?>
            <span class="notice-department"><?= htmlspecialchars($row['department']) ?></span>
          <?php endif; ?>
        </div>
        
        <?php if(!empty($row['title'])): ?>
          <h3 class="notice-title"><?= htmlspecialchars($row['title']) ?></h3>
        <?php endif; ?>
        
        <div class="notice-content">
          <?= nl2br(htmlspecialchars($row['notice'])) ?>
        </div>
        
        <?php if(!empty($row['link'])): ?>
          <div class="notice-footer">
            <a href="<?= htmlspecialchars($row['link']) ?>" class="notice-link" target="_blank">View Details →</a>
          </div>
        <?php endif; ?>
      </div>
    <?php endwhile; ?>
  </div>
</main>

<?php
   include 'footer.php';
?>

<script>
  function toggleMenu() {
    var navLinks = document.getElementById("nav-links");
    navLinks.classList.toggle("active");
  }
</script>

</body>
</html>