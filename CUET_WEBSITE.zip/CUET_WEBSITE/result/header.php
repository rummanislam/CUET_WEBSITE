

<header>
<div class="logo">
  <img src="logo.png" alt="CUET Logo">
  <h2 style="color:white">CUET</h2>
</div>

<div class ="menu-icon" onclick="toggleMenu()">☰</div>

<nav id="nav-links">
  <a href="index.php">Home</a>
  <a href="about.php">About CUET</a>
  <a href="academic.php">Academic</a>
  <a href="alumni.php">Alumni</a>
  <a href="notice.php">Notice</a>
  <a href="Login_form/index.php" target="_blank">Student Login</a>
  <a href="admin_login/index.php" target="_blank">Admin</a>
</nav>
</header>


