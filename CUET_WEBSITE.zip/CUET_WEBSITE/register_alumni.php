<?php
// Database connection
include 'connect.php';
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process form submission
$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $student_id = $conn->real_escape_string($_POST['student_id']);
    $batch = $conn->real_escape_string($_POST['batch']);
    $hall = $conn->real_escape_string($_POST['hall']);
    $current_status = $conn->real_escape_string($_POST['current_status']);
    $living_place = $conn->real_escape_string($_POST['living_place']);

    // Verify student information
    $verify_sql = "SELECT * FROM students_info 
                  WHERE id = '$student_id' 
                  AND email = '$email' 
                  AND batch = '$batch'";
    $verify_result = $conn->query($verify_sql);

    if ($verify_result->num_rows > 0) {
        // Check if already registered
        $check_sql = "SELECT * FROM alumni WHERE student_id = '$student_id' OR email = '$email'";
        $check_result = $conn->query($check_sql);
        
        if ($check_result->num_rows > 0) {
            $message = '<div class="alert alert-warning">You are already registered as an alumni!</div>';
        } else {
            // Insert into alumni table
            $insert_sql = "INSERT INTO alumni (student_id, name, email, batch, hall, current_status, living_place)
                          VALUES ('$student_id', '$name', '$email', '$batch', '$hall', '$current_status', '$living_place')";
            
            if ($conn->query($insert_sql)) {
                $message = '<div class="alert alert-success">Registration successful! Welcome to CUET Alumni Network.</div>';
            } else {
                $message = '<div class="alert alert-danger">Registration failed. Please try again.</div>';
            }
        }
    } else {
        $message = '<div class="alert alert-danger">Registration unsuccessful. Please enter correct student information.</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Registration | CUET</title>
    <link rel="icon" href="logo.png" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        .registration-container {
            max-width: 800px;
            margin: 50px auto;
            padding: 30px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        .registration-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .registration-header h2 {
            color: #2c3e50;
            margin-bottom: 10px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #34495e;
        }
        .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        .btn-submit {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s;
        }
        .btn-submit:hover {
            background-color: #2980b9;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
        }
        .alert-warning {
            background-color: #fff3cd;
            color: #856404;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <div class="registration-container">
            <div class="registration-header">
                <h2><i class="fas fa-user-plus"></i> Alumni Registration</h2>
                <p>Join the CUET Alumni Network and stay connected with your alma mater</p>
            </div>
            
            <?php echo $message; ?>
            
            <form action="register_alumni.php" method="POST">
                <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text" id="name" name="name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="student_id">Student ID</label>
                    <input type="text" id="student_id" name="student_id" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="batch">Batch</label>
                    <input type="text" id="batch" name="batch" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="hall">Hall of Residence</label>
                    <input type="text" id="hall" name="hall" class="form-control">
                </div>
                
                <div class="form-group">
                    <label for="current_status">Current Status</label>
                    <select id="current_status" name="current_status" class="form-control" required>
                        <option value="">Select your current status</option>
                        <option value="Working Professional">Working Professional</option>
                        <option value="Entrepreneur">Entrepreneur</option>
                        <option value="Researcher">Researcher</option>
                        <option value="Higher Studies">Higher Studies</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="living_place">Current Place of Living</label>
                    <input type="text" id="living_place" name="living_place" class="form-control" required>
                </div>
                
                <button type="submit" class="btn-submit">Register as Alumni</button>
            </form>
        </div>
    </div>
    
    <?php include 'footer.php'; ?>
</body>
</html>