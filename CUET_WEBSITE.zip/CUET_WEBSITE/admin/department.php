<?php
session_start();
include 'connect.php';

// Check if user is logged in as admin
// if (!isset($_SESSION['admin_logged_in'])) {
//     header("Location: ../admin_login/login.php");
//     exit;
// }

// Add new department
if (isset($_POST['add_department'])) {
    $dept_name = $_POST['dept_name'];
    $dept_code = $_POST['dept_code'];
    $dept_head = $_POST['dept_head'];
    $total_students = $_POST['total_students'];
    $description = $_POST['description'];
    
    // Handle file upload for department logo
    $logo_filename = '';
    if (isset($_FILES['dept_logo']) && $_FILES['dept_logo']['error'] == 0) {
        $targetDir = "uploads/departments/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true);
        }
        
        $fileExt = pathinfo($_FILES['dept_logo']['name'], PATHINFO_EXTENSION);
        $logo_filename = uniqid() . '.' . $fileExt;
        $targetFile = $targetDir . $logo_filename;
        
        if (!move_uploaded_file($_FILES['dept_logo']['tmp_name'], $targetFile)) {
            $logo_filename = ''; // Reset if upload failed
        }
    }
    
    $conn->query("INSERT INTO departments (name, code, head_name, total_students, description, logo_filename) 
                 VALUES ('$dept_name', '$dept_code', '$dept_head', '$total_students', '$description', '$logo_filename')");
    
    header("Location: department.php");
    exit;
}

// Delete department
if (isset($_GET['delete_dept'])) {
    $dept_id = $_GET['delete_dept'];
    $conn->query("DELETE FROM departments WHERE id = $dept_id");
    header("Location: department.php");
    exit;
}

// Get all departments
$departments = [];
$result = $conn->query("SELECT * FROM departments ORDER BY name");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $departments[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Department Management | CUET Admin Panel</title>
  <link href="admin.css" rel="stylesheet">
  <link rel="icon" href="logo.png" type="image/png">
  <link href="../style.css" rel="stylesheet">
  <style>
    /* Additional styles for department page */
    .department-card {
      background-color: #fff;
      border-radius: 12px;
      padding: 25px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.03);
      transition: all 0.3s ease;
      margin-bottom: 20px;
      border-left: 4px solid #3498db;
    }
    
    .department-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    }
    
    .department-header {
      display: flex;
      align-items: center;
      margin-bottom: 15px;
    }
    
    .department-logo {
      width: 60px;
      height: 60px;
      border-radius: 50%;
      object-fit: cover;
      margin-right: 15px;
      border: 2px solid #e0e6ed;
    }
    
    .department-title {
      font-size: 1.2rem;
      color: #2c3e50;
      margin: 0;
    }
    
    .department-code {
      font-size: 0.9rem;
      color: #7f8c8d;
      margin: 5px 0 0;
    }
    
    .department-details {
      margin-top: 15px;
    }
    
    .department-detail {
      display: flex;
      margin-bottom: 8px;
    }
    
    .detail-label {
      font-weight: 500;
      color: #34495e;
      min-width: 120px;
    }
    
    .department-actions {
      margin-top: 20px;
      display: flex;
      gap: 10px;
    }
    
    .edit-btn, .delete-btn {
      padding: 8px 15px;
      border-radius: 6px;
      font-size: 14px;
      cursor: pointer;
      transition: all 0.3s;
      text-decoration: none;
    }
    
    .edit-btn {
      background-color: #3498db;
      color: white;
      border: none;
    }
    
    .edit-btn:hover {
      background-color: #2980b9;
    }
    
    .delete-btn {
      background-color: #e74c3c;
      color: white;
      border: none;
    }
    
    .delete-btn:hover {
      background-color: #c0392b;
    }
    
    .department-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
      gap: 20px;
      margin-top: 30px;
    }
    
    #deptLogoPreview {
      max-width: 100px;
      max-height: 100px;
      margin-top: 10px;
      display: none;
      border-radius: 6px;
    }
  </style>
</head>
<body>




<header>
  <div class="logo">
    <img src="logo.png" alt="CUET Logo">
    <h2>CUET</h2>
  </div>
  
  <div class="menu-icon" onclick="toggleMenu()">☰</div>
  
  <nav id="nav-links">
    <a href="../index.php">Home</a>
      <a href="../about.php">About CUET</a>
      <a href="../academic.php">Academic</a>
      <a href="../alumni.php">Alumni</a>
      <a href="../notice.php">Notice</a>
    
    
    <div class="dropdown">
      <a href="#" class="dropbtn">Login</a>
      <div class="dropdown-content">
         <a href="../Login_form/index.php" target="_blank">Student</a>
      <a href="#" >Admin</a>
      
      </div>
    </div>
    <a href="../admin_login/logout.php" target="_blank">Logout</a>
  </nav>
</header>






















<!-- 

  <header>
    <div class="logo">
      <img src="logo.png" alt="CUET Logo">
      <h2>CUET</h2>
    </div>

    <div class="menu-icon" onclick="toggleMenu()">☰</div>

    <nav id="nav-links">
      <a href="../index.php">Home</a>
      <a href="../about.php">About CUET</a>
      <a href="../academic.php">Academic</a>
      <a href="../alumni.php">Alumni</a>
      <a href="../notice.php">Notice</a>
      <a href="../Login_form/index.php" target="_blank">Student Login</a>
      <a href="#">Admin</a>
      <a href="../admin_login/logout.php" target="_blank">Logout</a>
    </nav>
  </header> -->

  <div class="sidebar" id="sidebar">
    <div class="sidebar-toggle">
      <span class="toggle-btn" onclick="toggleSidebar()">&#9776;</span>
    </div>
    <h2>Admin Panel</h2>
    <ul>
      <li><a href="admin.php">Dashboard</a></li>
      <li><a href="admin.php#studentSection">Update Student info</a></li>
      <li><a href="admin.php#teacherSection">Update Teacher info</a></li>
      <li><a href="student_list.php" target="_blank">Student List</a></li>
      <li><a href="teacher_list.php" target="_blank">Teachers List</a></li>
      <li><a href="#">Courses</a></li>
      <li><a href="department.php" class="active">Departments</a></li>
      <li><a href="admin.php#noticeSection">Notices</a></li>
      <li><a href="result.php">Publish Result</a></li>
      <li><a href="admin_registration.php">Course Registration</a></li>
      <li><a href="../admin_login/logout.php">Logout</a></li>
    </ul>
  </div>

  <div class="main-content">
    <div class="header">
      <span class="toggle-btn" onclick="toggleSidebar()">&#9776;</span>
      <h1>Department Management</h1>
    </div>

    <div class="dashboard">
      <div class="card">
        <h3>Total Departments</h3>
        <p><?php echo count($departments); ?></p>
      </div>
      <div class="card">
        <h3>Total Students</h3>
        <p>
          <?php 
            $total = 0;
            foreach ($departments as $dept) {
              $total += $dept['total_students'];
            }
            echo number_format($total);
          ?>
        </p>
      </div>
      <div class="card">
        <h3>Active Departments</h3>
        <p><?php echo count($departments); ?></p>
      </div>
    </div>

    <div class="student-section">
      <h2>Add New Department</h2>
      
      <form action="" method="post" enctype="multipart/form-data" class="student-form">
        <div class="student-form-container">
          <div class="student-form-column">
            <div class="student-form-group">
              <label for="dept_name">Department Name</label>
              <input type="text" name="dept_name" class="student-form-control" id="dept_name" placeholder="Enter department name" required>
            </div>
            
            <div class="student-form-group">
              <label for="dept_code">Department Code</label>
              <input type="text" name="dept_code" class="student-form-control" id="dept_code" placeholder="Enter department code" required>
            </div>
            
            <div class="student-form-group">
              <label for="dept_head">Department Head</label>
              <input type="text" name="dept_head" class="student-form-control" id="dept_head" placeholder="Enter department head name" required>
            </div>
          </div>
          
          <div class="student-form-column">
            <div class="student-form-group">
              <label for="total_students">Total Students</label>
              <input type="number" name="total_students" class="student-form-control" id="total_students" placeholder="Enter total students" required>
            </div>
            
            <div class="student-form-group">
              <label for="description">Description</label>
              <textarea name="description" class="student-form-control" id="description" rows="3" placeholder="Enter department description"></textarea>
            </div>
            
            <div class="student-form-group">
              <label for="dept_logo">Department Logo</label>
              <input type="file" name="dept_logo" class="student-photo-upload" id="dept_logo" accept="image/*">
              <img id="deptLogoPreview" class="student-photo-preview" alt="Logo preview">
            </div>
          </div>
        </div>
        
        <div class="student-action-buttons">
          <button type="submit" name="add_department" class="student-submit-btn">Add Department</button>
        </div>
      </form>
    </div>

    <div class="student-section">
      <h2>All Departments</h2>
      
      <?php if (empty($departments)): ?>
        <p>No departments found. Please add departments.</p>
      <?php else: ?>
        <div class="department-grid">
          <?php foreach ($departments as $dept): ?>
            <div class="department-card">
              <div class="department-header">
                <?php if (!empty($dept['logo_filename'])): ?>
                  <img src="uploads/departments/<?php echo htmlspecialchars($dept['logo_filename']); ?>" class="department-logo" alt="<?php echo htmlspecialchars($dept['name']); ?>">
                <?php else: ?>
                  <div class="department-logo" style="background-color: #e0e6ed; display: flex; align-items: center; justify-content: center;">
                    <span style="font-size: 1.5rem;"><?php echo substr($dept['name'], 0, 1); ?></span>
                  </div>
                <?php endif; ?>
                <div>
                  <h3 class="department-title"><?php echo htmlspecialchars($dept['name']); ?></h3>
                  <p class="department-code"><?php echo htmlspecialchars($dept['code']); ?></p>
                </div>
              </div>
              
              <div class="department-details">
                <div class="department-detail">
                  <span class="detail-label">Head of Department:</span>
                  <span><?php echo htmlspecialchars($dept['head_name']); ?></span>
                </div>
                <div class="department-detail">
                  <span class="detail-label">Total Students:</span>
                  <span><?php echo number_format($dept['total_students']); ?></span>
                </div>
                <div class="department-detail">
                  <span class="detail-label">Description:</span>
                  <span><?php echo htmlspecialchars($dept['description']); ?></span>
                </div>
              </div>
              
              <div class="department-actions">
                <a href="edit_department.php?id=<?php echo $dept['id']; ?>" class="edit-btn">Edit</a>
                <a href="?delete_dept=<?php echo $dept['id']; ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this department?')">Delete</a>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <script>
    function toggleSidebar() {
      const sidebar = document.getElementById('sidebar');
      sidebar.classList.toggle('show');
    }

    function toggleMenu() {
      var navLinks = document.getElementById("nav-links");
      navLinks.classList.toggle("active");
    }

    // Department logo preview
    document.getElementById('dept_logo').addEventListener('change', function(e) {
      const preview = document.getElementById('deptLogoPreview');
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
          preview.src = e.target.result;
          preview.style.display = 'block';
        }
        reader.readAsDataURL(file);
      } else {
        preview.style.display = 'none';
      }
    });
  </script>
</body>
</html>