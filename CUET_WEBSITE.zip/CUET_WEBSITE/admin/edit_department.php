<?php
session_start();
include 'connect.php';

// Check if user is logged in as admin
// if (!isset($_SESSION['admin_logged_in'])) {
//     header("Location: ../admin_login/login.php");
//     exit;
// }

// Get department ID from URL
$dept_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch department data
$department = [];
if ($dept_id > 0) {
    $result = $conn->query("SELECT * FROM departments WHERE id = $dept_id");
    if ($result && $result->num_rows > 0) {
        $department = $result->fetch_assoc();
    } else {
        header("Location: department.php");
        exit;
    }
} else {
    header("Location: department.php");
    exit;
}

// Handle form submission
if (isset($_POST['update_department'])) {
    $dept_name = $conn->real_escape_string($_POST['dept_name']);
    $dept_code = $conn->real_escape_string($_POST['dept_code']);
    $dept_head = $conn->real_escape_string($_POST['dept_head']);
    $total_students = intval($_POST['total_students']);
    $description = $conn->real_escape_string($_POST['description']);
    
    // Handle file upload
    $logo_filename = $department['logo_filename']; // Keep existing if no new file uploaded
    if (isset($_FILES['dept_logo']) && $_FILES['dept_logo']['error'] == 0) {
        $targetDir = "uploads/departments/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true);
        }
        
        // Delete old logo if exists
        if (!empty($logo_filename) && file_exists($targetDir . $logo_filename)) {
            unlink($targetDir . $logo_filename);
        }
        
        $fileExt = pathinfo($_FILES['dept_logo']['name'], PATHINFO_EXTENSION);
        $logo_filename = uniqid() . '.' . $fileExt;
        $targetFile = $targetDir . $logo_filename;
        
        if (!move_uploaded_file($_FILES['dept_logo']['tmp_name'], $targetFile)) {
            $logo_filename = $department['logo_filename']; // Revert to old if upload fails
        }
    }
    
    $sql = "UPDATE departments SET 
            name = '$dept_name',
            code = '$dept_code',
            head_name = '$dept_head',
            total_students = $total_students,
            description = '$description',
            logo_filename = '$logo_filename'
            WHERE id = $dept_id";
    
    if ($conn->query($sql)) {
        $_SESSION['message'] = "Department updated successfully!";
        header("Location: department.php");
        exit;
    } else {
        $error = "Error updating department: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Edit Department | CUET Admin Panel</title>
  <link rel="icon" href="logo.png" type="image/png">
  <link href="admin.css" rel="stylesheet">
  <link href="../style.css" rel="stylesheet">
  <style>
    /* Add the same styles from department.php */
    #deptLogoPreview {
      max-width: 100px;
      max-height: 100px;
      margin-top: 10px;
      border-radius: 6px;
    }
    .current-logo {
      max-width: 100px;
      margin-bottom: 10px;
    }
  </style>
</head>
<body>




<header>
  <div class="logo">
    <img src="logo.png" alt="CUET Logo">
    <h2>CUET</h2>
  </div>
  
  <div class="menu-icon" onclick="toggleMenu()">☰</div>
  
  <nav id="nav-links">
    <a href="../index.php">Home</a>
      <a href="../about.php">About CUET</a>
      <a href="../academic.php">Academic</a>
      <a href="../alumni.php">Alumni</a>
      <a href="../notice.php">Notice</a>
    
    
    <div class="dropdown">
      <a href="#" class="dropbtn">Login</a>
      <div class="dropdown-content">
         <a href="../Login_form/index.php" target="_blank">Student</a>
      <a href="#" >Admin</a>
      
      </div>
    </div>
    <a href="../admin_login/logout.php" target="_blank">Logout</a>
  </nav>
</header>

























<!-- 
  <header>
    <div class="logo">
      <img src="logo.png" alt="CUET Logo">
      <h2>CUET</h2>
    </div>

    <div class="menu-icon" onclick="toggleMenu()">☰</div>

    <nav id="nav-links">
      <a href="../index.php">Home</a>
      <a href="../about.php">About CUET</a>
      <a href="../academic.php">Academic</a>
      <a href="../alumni.php">Alumni</a>
      <a href="../notice.php">Notice</a>
      <a href="../Login_form/index.php" target="_blank">Student Login</a>
      <a href="#">Admin</a>
      <a href="../admin_login/logout.php" target="_blank">Logout</a>
    </nav>
  </header> -->

  <div class="sidebar" id="sidebar">
    <div class="sidebar-toggle">
      <span class="toggle-btn" onclick="toggleSidebar()">&#9776;</span>
    </div>
    <h2>Admin Panel</h2>
    <ul>
      <li><a href="admin.php">Dashboard</a></li>
      <li><a href="admin.php#studentSection">Update Student info</a></li>
      <li><a href="admin.php#teacherSection">Update Teacher info</a></li>
      <li><a href="student_list.php" target="_blank">Student List</a></li>
      <li><a href="teacher_list.php" target="_blank">Teachers List</a></li>
      <li><a href="#">Courses</a></li>
      <li><a href="department.php" class="active">Departments</a></li>
      <li><a href="admin.php#noticeSection">Notices</a></li>
      <li><a href="result.php">Publish Result</a></li>
      <li><a href="admin_registration.php">Course Registration</a></li>
      <li><a href="../admin_login/logout.php">Logout</a></li>
    </ul>
  </div>

  <div class="main-content">
    <div class="header">
      <span class="toggle-btn" onclick="toggleSidebar()">&#9776;</span>
      <h1>Edit Department: <?php echo htmlspecialchars($department['name']); ?></h1>
    </div>

    <div class="student-section">
      <?php if (isset($error)): ?>
        <div class="error-message" style="color: red; margin-bottom: 15px;">
          <?php echo $error; ?>
        </div>
      <?php endif; ?>
      
      <form action="" method="post" enctype="multipart/form-data" class="student-form">
        <div class="student-form-container">
          <div class="student-form-column">
            <div class="student-form-group">
              <label for="dept_name">Department Name</label>
              <input type="text" name="dept_name" class="student-form-control" id="dept_name" 
                     value="<?php echo htmlspecialchars($department['name']); ?>" required>
            </div>
            
            <div class="student-form-group">
              <label for="dept_code">Department Code</label>
              <input type="text" name="dept_code" class="student-form-control" id="dept_code" 
                     value="<?php echo htmlspecialchars($department['code']); ?>" required>
            </div>
            
            <div class="student-form-group">
              <label for="dept_head">Department Head</label>
              <input type="text" name="dept_head" class="student-form-control" id="dept_head" 
                     value="<?php echo htmlspecialchars($department['head_name']); ?>" required>
            </div>
          </div>
          
          <div class="student-form-column">
            <div class="student-form-group">
              <label for="total_students">Total Students</label>
              <input type="number" name="total_students" class="student-form-control" id="total_students" 
                     value="<?php echo htmlspecialchars($department['total_students']); ?>" required>
            </div>
            
            <div class="student-form-group">
              <label for="description">Description</label>
              <textarea name="description" class="student-form-control" id="description" rows="3"><?php 
                echo htmlspecialchars($department['description']); 
              ?></textarea>
            </div>
            
            <div class="student-form-group">
              <label for="dept_logo">Department Logo</label>
              <?php if (!empty($department['logo_filename'])): ?>
                <div>
                  <p>Current Logo:</p>
                  <img src="uploads/departments/<?php echo htmlspecialchars($department['logo_filename']); ?>" 
                       class="current-logo" alt="Current department logo">
                </div>
              <?php endif; ?>
              <input type="file" name="dept_logo" class="student-photo-upload" id="dept_logo" accept="image/*">
              <img id="deptLogoPreview" class="student-photo-preview" alt="Logo preview">
            </div>
          </div>
        </div>
        
        <div class="student-action-buttons">
          <button type="submit" name="update_department" class="student-submit-btn">Update Department</button>
          <a href="department.php" class="student-view-btn">Cancel</a>
        </div>
      </form>
    </div>
  </div>

  <script>
    function toggleSidebar() {
      const sidebar = document.getElementById('sidebar');
      sidebar.classList.toggle('show');
    }

    function toggleMenu() {
      var navLinks = document.getElementById("nav-links");
      navLinks.classList.toggle("active");
    }

    // Department logo preview
    document.getElementById('dept_logo').addEventListener('change', function(e) {
      const preview = document.getElementById('deptLogoPreview');
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
          preview.src = e.target.result;
          preview.style.display = 'block';
        }
        reader.readAsDataURL(file);
      } else {
        preview.style.display = 'none';
      }
    });
  </script>
</body>
</html>