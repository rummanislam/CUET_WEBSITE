-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 29, 2025 at 10:08 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cuet_website`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` int(10) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `firstName`, `lastName`, `email`, `password`) VALUES
(2, 'admin', 'admin', 'rummanislam808269@gmail.com', 'b0baee9d279d34fa1dfd71aadb908c3f'),
(3, 'Md Hamed', 'Hasan', 'hamed2002273@gmail.com', 'b0baee9d279d34fa1dfd71aadb908c3f');

-- --------------------------------------------------------

--
-- Table structure for table `alumni`
--

CREATE TABLE `alumni` (
  `id` int(11) NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `batch` varchar(20) NOT NULL,
  `hall` varchar(50) DEFAULT NULL,
  `current_status` varchar(100) DEFAULT NULL,
  `living_place` varchar(100) DEFAULT NULL,
  `registration_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `alumni`
--

INSERT INTO `alumni` (`id`, `student_id`, `name`, `email`, `batch`, `hall`, `current_status`, `living_place`, `registration_date`) VALUES
(1, '2108019', 'Syed Rumman Islam', 'u2108019@student.cuet.ac.bd', '21', 'KKNIH', 'Higher Studies', 'BD', '2025-07-07 12:50:00');

-- --------------------------------------------------------

--
-- Table structure for table `course_registrations`
--

CREATE TABLE `course_registrations` (
  `id` int(11) NOT NULL,
  `student_email` varchar(100) NOT NULL,
  `student_id` varchar(50) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `department` varchar(50) NOT NULL,
  `batch` varchar(10) NOT NULL,
  `hall` varchar(50) NOT NULL,
  `level_term` varchar(20) NOT NULL,
  `payment_method` varchar(20) NOT NULL,
  `transaction_id` varchar(50) NOT NULL,
  `course_fee` decimal(10,2) NOT NULL,
  `registration_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('pending','approved') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `course_registrations`
--

INSERT INTO `course_registrations` (`id`, `student_email`, `student_id`, `student_name`, `department`, `batch`, `hall`, `level_term`, `payment_method`, `transaction_id`, `course_fee`, `registration_date`, `status`) VALUES
(8, 'u2108019@student.cuet.ac.bd', '2108019', 'Syed Rumman Islam', 'ETE', '21', 'KKNIH', 'Level 1 Term 1', 'bKash', 'fgdfgdfg', 3360.00, '2025-07-04 05:28:54', 'approved'),
(9, 'u2108019@student.cuet.ac.bd', '2108019', 'Syed Rumman Islam', 'ETE', '21', 'KKNIH', 'Level 1 Term 2', 'bKash', 'fsdf', 3360.00, '2025-07-04 06:05:10', 'approved'),
(10, 'u2108019@student.cuet.ac.bd', '2108019', 'Syed Rumman Islam', 'ETE', '21', 'KKNIH', 'Level 2 Term 1', 'bKash', 'sdfsfd', 3360.00, '2025-07-06 08:28:34', 'approved'),
(11, 'u2108019@student.cuet.ac.bd', '2108019', 'Syed Rumman Islam', 'ETE', '21', 'KKNIH', 'Level 2 Term 2', 'bKash', 'vxvcv', 5224.00, '2025-07-07 12:20:59', 'approved'),
(12, 'u2108019@student.cuet.ac.bd', '2108019', 'Syed Rumman Islam', 'ETE', '21', 'KKNIH', 'Level 3 Term 1', 'bKash', 'rkjfhkrfhds', 3360.00, '2025-07-08 03:25:22', 'approved'),
(13, 'u2108019@student.cuet.ac.bd', '2108019', 'Syed Rumman Islam', 'ETE', '21', 'KKNIH', 'Level 3 Term 2', 'bKash', 'jhbh', 1.00, '2025-07-08 04:04:23', 'approved'),
(14, 'u2108028@student.cuet.ac.bd', '2108028', 'Piyal Chakraborty', 'ETE', '21', 'KKNIH', 'Level 1 Term 1', 'Rocket', 'reujgrjgorejgo', 2490.00, '2025-07-08 04:15:42', 'approved'),
(15, 'u2108019@student.cuet.ac.bd', '2108019', 'Syed Rumman Islam', 'ETE', '21', 'KKNIH', 'Level 4 Term 1', 'bKash', 'vxvcv', 1200.00, '2025-07-22 05:44:59', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(10) NOT NULL,
  `head_name` varchar(100) NOT NULL,
  `total_students` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `logo_filename` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `code`, `head_name`, `total_students`, `description`, `logo_filename`, `created_at`) VALUES
(1, 'Electronics And Telecommunication Engineering', 'ETE', 'Dr. Md. Jahedul Islam', 60, 'Electronics And Telecommunication Engineering', '', '2025-07-07 11:12:30'),
(2, 'Electrical And Electronics Engineering', 'EEE', 'Dr. Tofael Ahmed', 180, 'Electrical And Electronics Engineering', '', '2025-07-07 11:34:37'),
(3, 'Civil Engineering', 'CE', 'Dr. Aysha Akter', 180, 'Civil Engineering', '', '2025-07-07 11:42:10'),
(4, 'Mechanical Engineering', 'ME', 'Dr. Muhammad Mostafa Kamal Bhuiya', 180, 'Mechanical Engineering', '', '2025-07-07 11:43:37'),
(5, 'Computer Science Engineering', 'CSE', 'Dr. Pranab Kumar Dhar', 130, 'Computer Science Engineering', '', '2025-07-07 11:44:37'),
(6, 'Water Resource Engineering', 'WRE', 'Dr. Mst. Farzana Rahman Zuthi', 60, '', '', '2025-07-07 11:46:13'),
(7, 'Petroleum And Mining Engineering', 'PME', 'Dr. Abu Shadat Muhammad Sayem', 30, '', '', '2025-07-07 11:48:52'),
(8, 'Mechatronics And Industrial Engineering', 'MIE', 'Dr. Prasanjit Das', 30, '', '', '2025-07-07 11:50:07'),
(9, 'Urban And Regional Planning', 'URP', 'Debasish Roy Raja', 30, '', '', '2025-07-07 11:51:25'),
(10, 'Architecture', 'ARCH', 'Dr. Sajal Chowdhury', 30, '', '', '2025-07-07 11:52:22'),
(11, 'Biomedical Engineering', 'BME', 'Dr. Nipu Kumar Das', 30, '', '', '2025-07-07 11:53:18'),
(12, 'Materials And Metallurgical Engineering', 'MME', 'Dr. Md. Arafat Rahman', 30, '', '', '2025-07-07 11:54:29');

-- --------------------------------------------------------

--
-- Table structure for table `important_notice`
--

CREATE TABLE `important_notice` (
  `sl` int(10) NOT NULL,
  `date` datetime DEFAULT current_timestamp(),
  `notice` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `important_notice`
--

INSERT INTO `important_notice` (`sl`, `date`, `notice`) VALUES
(8, '2025-06-20 12:08:48', 'The site is under development.');

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `sl` int(11) NOT NULL,
  `date` datetime DEFAULT current_timestamp(),
  `notice` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`sl`, `date`, `notice`) VALUES
(3, '2025-05-26 19:24:28', 'University is off today'),
(6, '2025-07-04 15:09:47', 'Admission is going on'),
(7, '2025-07-04 15:10:28', 'Orientation of 24 batch is going to be held of 24th July 2025');

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE `photos` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `uploaded_on` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` (`id`, `email`, `filename`, `uploaded_on`) VALUES
(1, 'u21080ffffff19@student.cuet.ac.bd', 'photo_6165753624941152365_y.jpg', '2025-05-31 11:56:03'),
(3, 'u2108016@student.cuet.ac.bd', 'WhatsApp Image 2025-05-31 at 12.19.08 PM.jpeg', '2025-05-31 12:19:59'),
(5, 'u2108034@student.cuet.ac.bd', 'WhatsApp Image 2025-05-31 at 12.44.32 PM.jpeg', '2025-05-31 12:45:18'),
(7, 'u2108017@student.cuet.ac.bd', 'WhatsApp Image 2025-04-10 at 12.20.19 PM.jpeg', '2025-06-20 11:59:17'),
(13, 'u2108019@student.cuet.ac.bd', '6866b8624bbba.jpg', '2025-07-03 23:05:38'),
(14, 'u2108018@student.cuet.ac.bd', 'male.jpg', '2025-07-06 13:47:50'),
(15, 'u2108005@student.cuet.ac.bd', 'male.jpg', '2025-07-06 13:50:33'),
(16, 'u2108022@student.cuet.ac.bd', 'male.jpg', '2025-07-06 13:58:31'),
(17, 'u2108028@student.cuet.ac.bd', 'male.jpg', '2025-07-08 10:13:44'),
(18, 'u2101024@student.cuet.ac.bd', 'male.jpg', '2025-07-21 19:54:38'),
(19, 'u2103049@student.cuet.ac.bd', 'male.jpg', '2025-07-21 19:57:26'),
(20, 'u2104028@student.cuet.ac.bd', 'male.jpg', '2025-07-21 20:24:09'),
(21, 'u2102130@student.cuet.ac.bd', 'male.jpg', '2025-07-21 20:26:07'),
(22, 'u2105004@student.cuet.ac.bd', 'male.jpg', '2025-07-21 20:27:39'),
(23, 'u2111015@student.cuet.ac.bd', 'male.jpg', '2025-07-21 20:30:48'),
(24, 'u2112024@student.cuet.ac.bd', 'male.jpg', '2025-07-21 20:32:02'),
(25, 'u2103034@student.cuet.ac.bd', 'male.jpg', '2025-07-21 20:34:22'),
(26, 'u2102090@student.cuet.ac.bd', 'male.jpg', '2025-07-21 20:35:32'),
(27, 'u2104044@student.cuet.ac.bd', 'male.jpg', '2025-07-21 20:37:06'),
(28, 'u2111030@student.cuet.ac.bd', 'male.jpg', '2025-07-21 20:38:35'),
(29, 'u2112019@student.cuet.ac.bd', 'male.jpg', '2025-07-21 20:40:59');

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `course_code` varchar(50) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `course_credit` decimal(3,2) NOT NULL,
  `batch` int(11) NOT NULL,
  `grade` varchar(5) NOT NULL,
  `semester` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`id`, `email`, `department`, `course_code`, `course_name`, `course_credit`, `batch`, `grade`, `semester`, `created_at`) VALUES
(13, 'u2108019@student.cuet.ac.bd', 'ETE', 'EEE 181', 'Basic Electrical Engineering', 4.00, 21, 'A+', 'level1_term1', '2025-06-28 07:44:31'),
(14, 'u2108019@student.cuet.ac.bd', 'ETE', 'EEE 182', 'Basic Electrical Engineering Sessional', 1.50, 21, 'A+', 'level1_term1', '2025-06-28 07:45:32'),
(15, 'u2108019@student.cuet.ac.bd', 'ETE', 'MATH 181', 'Differential And Integral Calculus', 3.00, 21, 'B+', 'level1_term1', '2025-06-28 07:46:32'),
(16, 'u2108019@student.cuet.ac.bd', 'ETE', 'MATH 181', 'Ordinary and Partial Diff. Eqn.', 3.00, 21, 'B+', 'level1_term1', '2025-06-28 07:47:47'),
(17, 'u2108019@student.cuet.ac.bd', 'ETE', 'CHEM 181', 'Chemistry', 3.00, 21, 'A', 'level1_term1', '2025-06-28 07:48:45'),
(18, 'u2108019@student.cuet.ac.bd', 'ETE', 'CHEM 182', 'Chemistry Sessional', 1.50, 21, 'A+', 'level1_term1', '2025-06-28 07:49:25'),
(19, 'u2108019@student.cuet.ac.bd', 'ETE', 'HUM 181', 'Technical English', 3.00, 21, 'A-', 'level1_term1', '2025-06-28 07:50:02'),
(22, 'u2108019@student.cuet.ac.bd', 'ETE', 'ME 182', 'Mechanical Drawing', 0.75, 21, 'A', 'level1_term1', '2025-06-28 08:05:09'),
(23, 'u2108019@student.cuet.ac.bd', 'ETE', 'MATH 185', 'Vector Analysis', 3.00, 21, 'C', 'level1_term2', '2025-06-28 08:08:16'),
(24, 'u2108019@student.cuet.ac.bd', 'ETE', 'ETE 102', 'Electronics Sessional', 1.50, 21, 'B-', 'level1_term2', '2025-06-28 08:09:07'),
(25, 'u2108019@student.cuet.ac.bd', 'ETE', 'ETE-101', 'Electronics I', 3.00, 21, 'B', 'level1_term2', '2025-06-28 08:09:58'),
(26, 'u2108019@student.cuet.ac.bd', 'ETE', 'EEE 183', 'Electrical Machines', 3.00, 21, 'B-', 'level1_term2', '2025-06-28 08:10:41'),
(27, 'u2108019@student.cuet.ac.bd', 'ETE', 'EEE 184', 'Electrical Machines Sessional', 1.50, 21, 'B+', 'level1_term2', '2025-06-28 08:12:08'),
(28, 'u2108019@student.cuet.ac.bd', 'ETE', 'PHY 181', 'Engineering Physics', 3.00, 21, 'B+', 'level1_term2', '2025-06-28 08:14:20'),
(29, 'u2108019@student.cuet.ac.bd', 'ETE', 'CSE 181', 'Computer Programming ', 4.00, 21, 'A+', 'level1_term2', '2025-06-28 08:15:20'),
(30, 'u2108019@student.cuet.ac.bd', 'ETE', 'PHY 182', 'Engineering Physics Sessional', 1.50, 21, 'A', 'level1_term2', '2025-06-28 08:16:19'),
(31, 'u2108019@student.cuet.ac.bd', 'ETE', 'CSE 182', 'Computer Programming Sessional', 1.50, 21, 'A+', 'level1_term2', '2025-06-28 08:17:15'),
(35, 'u2108016@student.cuet.ac.bd', 'ETE', 'EEE 181', 'Basic Electrical Engineering', 4.00, 21, 'A', 'level1_term1', '2025-07-21 07:25:04'),
(36, 'u2108016@student.cuet.ac.bd', 'ETE', 'EEE 182', 'Basic Electrical Engineering Sessional', 1.50, 21, 'A', 'level1_term1', '2025-07-21 07:25:43'),
(37, 'u2108016@student.cuet.ac.bd', 'ETE', 'MATH 181', 'Differential And Integral Calculus', 3.00, 21, 'A-', 'level1_term1', '2025-07-21 07:26:38'),
(38, 'u2108016@student.cuet.ac.bd', 'ETE', 'MATH 183', 'Ordinary and Partial Diff. Eqn.', 3.00, 21, 'A', 'level1_term1', '2025-07-21 07:27:14'),
(39, 'u2108016@student.cuet.ac.bd', 'ETE', 'CHEM 181', 'Chemistry', 3.00, 21, 'B+', 'level1_term1', '2025-07-21 07:29:39'),
(40, 'u2108016@student.cuet.ac.bd', 'ETE', 'CHEM 182', 'Chemistry Sessional', 1.50, 21, 'A', 'level1_term1', '2025-07-21 07:30:31'),
(41, 'u2108016@student.cuet.ac.bd', 'ETE', 'HUM 181', 'Technical English', 3.00, 21, 'B-', 'level1_term1', '2025-07-21 07:31:26'),
(42, 'u2108016@student.cuet.ac.bd', 'ETE', 'ME 182', 'Mechanical Drawing', 0.75, 21, 'A+', 'level1_term1', '2025-07-21 07:32:18'),
(43, 'u2108016@student.cuet.ac.bd', 'ETE', 'MATH 185', 'Vector Analysis', 3.00, 21, 'B', 'level1_term2', '2025-07-21 07:33:42'),
(45, 'u2108016@student.cuet.ac.bd', 'ETE', 'ETE 101', 'Electronics I', 3.00, 21, 'B', 'level1_term2', '2025-07-21 07:35:36'),
(46, 'u2108016@student.cuet.ac.bd', 'ETE', 'ETE 102', 'Electronics I Sessional', 1.50, 21, 'B-', 'level1_term2', '2025-07-21 07:36:48'),
(47, 'u2108016@student.cuet.ac.bd', 'ETE', 'EEE 184', 'Electrical Machines Sessional', 1.50, 21, 'A+', 'level1_term2', '2025-07-21 07:38:50'),
(48, 'u2108016@student.cuet.ac.bd', 'ETE', 'EEE 183', 'Electrical Machines', 3.00, 21, 'B-', 'level1_term2', '2025-07-21 07:39:28'),
(49, 'u2108016@student.cuet.ac.bd', 'ETE', 'PHY 181', 'Engineering Physics', 3.00, 21, 'A-', 'level1_term2', '2025-07-21 07:40:15'),
(50, 'u2108016@student.cuet.ac.bd', 'ETE', 'PHY 182', 'Engineering Physics Sessional', 1.50, 21, 'A-', 'level1_term2', '2025-07-21 07:40:57'),
(51, 'u2108016@student.cuet.ac.bd', 'ETE', 'CSE 181', 'Computer Programming', 4.00, 21, 'A-', 'level1_term2', '2025-07-21 07:43:34'),
(52, 'u2108016@student.cuet.ac.bd', 'ETE', 'CSE 182', 'Computer Programming Sessional', 1.50, 21, 'A-', 'level1_term2', '2025-07-21 07:44:12');

-- --------------------------------------------------------

--
-- Table structure for table `students_info`
--

CREATE TABLE `students_info` (
  `sl` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `batch` varchar(20) DEFAULT NULL,
  `hall` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `students_info`
--

INSERT INTO `students_info` (`sl`, `name`, `id`, `email`, `contact`, `department`, `batch`, `hall`) VALUES
(13, 'Syed Rumman Islam', '2108019', 'u2108019@student.cuet.ac.bd', '01303808269', 'ETE', '21', 'KKNIH'),
(14, 'Hamed Hasan', '2108016', 'u2108016@student.cuet.ac.bd', '0170000000', 'ETE', '21', 'KKNIH'),
(15, 'Rahat Hossain', '2108034', 'u2108034@student.cuet.ac.bd', '0170000000', 'ETE', '21', 'SASH'),
(17, 'Mahbub Alam Miraz', '2108017', 'u2108017@student.cuet.ac.bd', '01730000000', 'ETE', '21', 'KKNIH'),
(20, 'Shamem Mia', '2108018', 'u2108018@student.cuet.ac.bd', '0170000000', 'ETE', '21', 'KKNIH'),
(21, 'Nazrul Islam', '2108005', 'u2108005@student.cuet.ac.bd', '0170000000', 'ETE', '21', 'KKNIH'),
(22, 'Amit', '2108022', 'u2108022@student.cuet.ac.bd', '0170000000', 'ETE', '21', 'SASH'),
(23, 'Piyal Chakraborty', '2108028', 'u2108028@student.cuet.ac.bd', '01400000000', 'ETE', '21', 'KKNIH'),
(24, 'Muij Muntasir', '2101024', 'u2101024@student.cuet.ac.bd', '01400000000', 'CE', '21', 'SASH'),
(25, 'Saleh Uddin', '2103049', 'u2103049@student.cuet.ac.bd', '01400000000', 'ME', '21', 'KKNIH'),
(26, 'Turja Das', '2104028', 'u2104028@student.cuet.ac.bd', '01400000000', 'CSE', '21', 'SMSH'),
(27, 'Md. Arefin', '2102130', 'u2102130@student.cuet.ac.bd', '01400000000', 'EEE', '21', 'KKNIH'),
(28, 'Ratul Paul', '2105004', 'u2105004@student.cuet.ac.bd', '01400000000', 'URP', '21', 'SASH'),
(29, 'Rahat Chy', '2111015', 'u2111015@student.cuet.ac.bd', '01400000000', 'BME', '21', 'SASH'),
(30, 'Ahnaf Meraj', '2112024', 'u2112024@student.cuet.ac.bd', '01400000000', 'MME', '21', 'KKNIH'),
(31, 'Md Anas', '2103034', 'u2103034@student.cuet.ac.bd', '01400000000', 'ME', '21', 'SMSH'),
(32, 'Shuvo Chy', '2102090', 'u2102090@student.cuet.ac.bd', '01400000000', 'EEE', '21', 'SMSH'),
(33, 'Joy Das', '2104044', 'u2104044@student.cuet.ac.bd', '01400000000', 'CSE', '21', 'SASH'),
(34, 'Abtahi Chy', '2111030', 'u2111030@student.cuet.ac.bd', '01400000000', 'BME', '21', 'KKNIH'),
(35, 'Samin Ishraq', '2112019', 'u2112019@student.cuet.ac.bd', '01400000000', 'MME', '21', 'SMSH');

-- --------------------------------------------------------

--
-- Table structure for table `teachers_info`
--

CREATE TABLE `teachers_info` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `portfolio_link` varchar(255) DEFAULT NULL,
  `undergrad_university` varchar(255) DEFAULT NULL,
  `department` varchar(100) NOT NULL,
  `join_date` date NOT NULL,
  `photo_filename` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `teachers_info`
--

INSERT INTO `teachers_info` (`id`, `name`, `email`, `designation`, `contact`, `portfolio_link`, `undergrad_university`, `department`, `join_date`, `photo_filename`) VALUES
(4, 'Dr. Md. Azad Hossain', 'azad@cuet.ac.bd', 'Professor', '+8801783756981', '', 'CUET', 'ETE', '2012-01-01', '687d247dab2a7.png'),
(5, 'Dr. Md. Jahedul Islam', 'jahed@cuet.ac.bd', 'Professor', '+8801792451681', '', 'KUET', 'ETE', '2025-01-01', '687d25e3abd59.png'),
(6, 'Dr. Md. Saiful Islam', 'saiful05eee@cuet.ac.bd', 'Associate Professor', '+8801840066254', '', 'CUET', 'ETE', '2013-01-01', '687d26921a179.png'),
(7, 'Dr. Nursadul Mamun', 'nursad.mamun@cuet.ac.bd', 'Assistant Professor', '+8801813977506', '', 'CUET', 'ETE', '2024-01-01', '687d27012bc5f.png'),
(8, 'Md. Farhad Hossain', 'farhad.hossain@cuet.ac.bd', 'Assistant Professor', '+8801601998766', '', 'CUET', 'ETE', '2020-01-01', '687d278c5fbcd.png'),
(9, 'Priyanti Paul Tumpa', 'priyanti.ete@cuet.ac.bd', 'Assistant Professor', '01710000000', '', 'CUET', 'ETE', '2020-01-01', '687d28da767ef.png'),
(11, 'Arif Istiaque Rupom', 'arif.ete@cuet.ac.bd', 'Lecturer', '01810000000', '', 'CUET', 'ETE', '2020-01-01', '687d2b74a27d3.png'),
(12, 'Gazi Jannatul Ferdous', 'jannatul.ferdous@cuet.ac.bd', 'Lecturer', '+8801783188423', '', 'CUET', 'ETE', '2024-01-01', '687d2becf2b7e.png'),
(13, 'Farhin Sultana', 'farhin.sultana@cuet.ac.bd', 'Lecturer', '01810000000', '', 'CUET', 'ETE', '2022-01-01', '687d2c4a96285.png'),
(14, 'Khaleda Akhter Sathi', 'sathi.ete@cuet.ac.bd', 'Lecturer', '01810000000', '', 'CUET', 'ETE', '2022-01-01', '687d2d42315cd.png'),
(15, 'Eftekhar Hossain', 'eftekhar.hossain@cuet.ac.bd', 'Assistant Professor', '+8801521532765', '', 'CUET', 'ETE', '2019-01-01', '687d2d9c875f9.png'),
(16, 'Khadija Akter', 'khadija.ete@cuet.ac.bd', 'Assistant Professor', '01810000000', '', 'CUET', 'ETE', '2020-01-01', '687d2e1298b52.png'),
(17, 'Taieba Taher', 'taieba.athay@cuet.ac.bd', 'Assistant Professor', '01810000000', '', 'CUET', 'ETE', '2020-01-01', '687d2e4ea9ee3.png');

-- --------------------------------------------------------

--
-- Table structure for table `university_history`
--

CREATE TABLE `university_history` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `photo_filename` varchar(255) DEFAULT NULL,
  `display_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `university_history`
--

INSERT INTO `university_history` (`id`, `title`, `description`, `photo_filename`, `display_order`, `created_at`, `updated_at`) VALUES
(3, 'The golden journey', 'Former Bangladesh Institute of Technology, Chittagong, abbreviated as BIT Chittagong is presently Chittagong University of Engineering & Technology (CUET). It is one of the prominent and prestigious autonomous self-degree-awarding institute in the engineering education of Bangladesh. This Institute was created out of Engineering College, Chittagong that was established in 1968. The Chittagong Engineering College functioned as the Faculty of Engineering of the University of Chittagong. Through a Government ordinance in 1986, the college was converted into an Institute of Technology. In 2003 this institute of technology was converted into a public university. The honorable President of Bangladesh is the Chancellor of the University.  <br><br>\r\n\r\nChittagong University Of Engineering & Technology abbreviated as CUET, is one of the prominent and prestigious degree awarding institute in the engineering education of Bangladesh. This University was created out of Engineering College, Chittagong, that was established in 1968. The Engineering College , Chittagong , functioned as the Faculty of Engineering of the University of Chittagong. Though a Government Ordinance in 1986 the college was converted into an institution (BIT, Chittagong).The honorable President of Bangladesh is the visitor of the institute . A Board of Governors headed by a Chairman appointed by the President is the policy making and administrative authority. There were three other similar Institutes of Technology in the country namely BIT Khulna, BIT Rajshahi and BIT Dhaka that are converted to Khulna University Of Engineering, Rajshashi University Of Engineering & Technology(RUET) & Technology(KUET),Dhaka University Of Engineering & Technology(DUET)  <br> <br>\r\n\r\nCUET is unique and incompatible due to its proximity to Chittagong, the major sea-port and the beautiful Hill city of the country. The University is situated by the side of the Chittagong-Kaptai road some 25 kilometers off from the center of Chittagong City. Moreover all the tourist attractions of the country like the large hydroelectric plant, the natural beauty of the lake of Kaptai, hill sports of Rangamati, Bandarban, the longest sea beach of the world and tourist resort of Cox\'s Bazar are only a few hours journey. <br> <br>\r\n   ', '686a2ce4ba136.jpg', 0, '2025-07-06 07:59:32', '2025-07-06 07:59:32');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `login_type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstName`, `lastName`, `email`, `password`, `login_type`) VALUES
(11, 'Syed Rumman ', 'Islam', 'u2108019@student.cuet.ac.bd', '827ccb0eea8a706c4c34a16891f84e7b', ''),
(12, 'Hamed', 'Hasan', 'u2108016@student.cuet.ac.bd', '827ccb0eea8a706c4c34a16891f84e7b', ''),
(13, 'Md.Rahat', 'Hossain', 'u2108034@student.cuet.ac.bd', '827ccb0eea8a706c4c34a16891f84e7b', ''),
(14, 'Shamem', 'Mia', 'u2108018@student.cuet.ac.bd', '827ccb0eea8a706c4c34a16891f84e7b', ''),
(15, 'Mahbub Alam', 'Miraz', 'u2108017@student.cuet.ac.bd', '827ccb0eea8a706c4c34a16891f84e7b', ''),
(16, 'Nazrul ', 'Islam', 'u2108005@student.cuet.ac.bd', '827ccb0eea8a706c4c34a16891f84e7b', ''),
(17, 'Anton', 'Alex', 'u21080180@student.cuet.ac.bd', '$2y$10$RjOdcRZgZqawHGMshVP08u.YcSerxx2L1xZ40TY2bGq', ''),
(18, 'Piyal', 'Chakraborty', 'u2108028@student.cuet.ac.bd', '827ccb0eea8a706c4c34a16891f84e7b', '');

-- --------------------------------------------------------

--
-- Table structure for table `vc_info`
--

CREATE TABLE `vc_info` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `photo_filename` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `vc_info`
--

INSERT INTO `vc_info` (`id`, `name`, `photo_filename`, `message`, `updated_at`) VALUES
(1, 'Prof. Dr. Mahmud Abdul Matin Bhuiyan', '686a2688283b1.jfif', 'The offer from the Peopleâ€™s Republic of Bangladesh government to serve as the Vice-Chancellor of Chittagong University of Engineering & Technology (CUET) was a time of immense honor and humility. Having spent many years here, I consider it an enormous honor to be able to serve the university, which holds immense significance for me. <br> <br>\r\n\r\nCUET has been at the forefront of cultivating excellence in engineering and technology education since its inception as an engineering college in 1968. Over the past 56 years, CUET has evolved into a prestigious institution comprising 18 departments and 4 research institutes. Each year, around 920 undergraduate students are admitted to 12 degree-awarding departments, while 13 departments and institutes provide postgraduate programs (MSc, MSc Engg, M.Engg, M.Phil, PhD). \r\n\r\nAt CUET, we are committed to developing top-tier human resources. We attract the brightest minds through highly competitive admission tests and provide them with globally relevant academic programs. Our dynamic curriculum is continuously updated to meet worldwide standards, preparing our students for a global career. Beyond classroom instruction, CUETâ€™s strategic location in southeast Bangladesh offers students unique opportunities for hands-on industrial exposure, as the Chittagong region is home to the nationâ€™s premier seaport and a diverse range of heavy and light industries. \r\n\r\nResearch and innovation are at the core of CUETâ€™s vision. We are actively collaborating with world-class universities and institutes to pioneer advances in renewable energy, intelligent computing, cutting-edge mechanical and infrastructural technologies, and other areas. Our research spans a wide range of disciplines, including biomedical, robotics, energy, mining, architecture, disaster management, and water resource planning, all in keeping with the United Nationsâ€™ Sustainable Development Goals. Furthermore, CUET fosters strong industry-academia partnerships to stimulate innovation and nurture future leaders. Many of our esteemed alumni now hold prominent positions in prestigious organizations both nationally and internationally.   \r\n\r\nLooking ahead, we are embarking on an ambitious strategic development plan to expand our institution. By 2032, we aim to establish 21 departments, four institutes, nine directorates, and a state-of-the-art central research laboratory. As Vice-Chancellor, I warmly invite alumni, donor agencies, organizations, philanthropists, and industrial leaders to join hands with CUET in realizing its full potential. We can all work together to help our countryâ€™s socioeconomic progress and advance humanity.\r\n\r\nI eagerly look forward to welcoming you to the serene and inspiring CUET campus, where innovation meets opportunity.\r\n\r\nWarm regards,\r\n\r\nProf. Dr. Mahmud Abdul Matin Bhuiyan\r\nVice-Chancellor\r\nChittagong University of Engineering & Technology (CUET)', '2025-07-06 08:05:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `alumni`
--
ALTER TABLE `alumni`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_id` (`student_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `course_registrations`
--
ALTER TABLE `course_registrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `important_notice`
--
ALTER TABLE `important_notice`
  ADD PRIMARY KEY (`sl`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`sl`),
  ADD UNIQUE KEY `sl.` (`sl`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `results`
--
ALTER TABLE `results`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`),
  ADD KEY `department` (`department`),
  ADD KEY `batch` (`batch`),
  ADD KEY `semester` (`semester`);

--
-- Indexes for table `students_info`
--
ALTER TABLE `students_info`
  ADD PRIMARY KEY (`sl`);

--
-- Indexes for table `teachers_info`
--
ALTER TABLE `teachers_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `university_history`
--
ALTER TABLE `university_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vc_info`
--
ALTER TABLE `vc_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `alumni`
--
ALTER TABLE `alumni`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `course_registrations`
--
ALTER TABLE `course_registrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `important_notice`
--
ALTER TABLE `important_notice`
  MODIFY `sl` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `results`
--
ALTER TABLE `results`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `students_info`
--
ALTER TABLE `students_info`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `teachers_info`
--
ALTER TABLE `teachers_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `university_history`
--
ALTER TABLE `university_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `vc_info`
--
ALTER TABLE `vc_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
