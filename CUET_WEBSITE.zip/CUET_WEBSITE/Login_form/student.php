<?php
session_start();
if ($_SESSION['login_type'] !== 'student') {
    header("Location: index.php");
    exit();
}
echo "Welcome Student, " . $_SESSION['email'];
?>
